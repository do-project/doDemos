//related to index.ui.ui
var root = ui("$");
root.on("touch", function() {
	//相应点击，但是不做任何处理，确保用户不能点击到下面
});