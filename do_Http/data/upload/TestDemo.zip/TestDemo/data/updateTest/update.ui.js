//related to scale.ui
var app = sm("do_App");

ui("do_Button_1").on("touch",function(){
	app.closePage();
})

ui("do_Button_2").on("touch",function(){
	app.openPage("source://view/OTHERS/scale/scale1.ui")
})