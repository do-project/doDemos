/**********************************************
 * Author : @Author
 * Timestamp : @Timestamp
 **********************************************/
var d1 = require("deviceone");
var app = d1.sm("do_App");
//var push = d1.sm("do_BaiduPush");
var nf = d1.sm("do_Notification");
var global = d1.sm("do_Global");

global.on("launch",function(data, e){
	d1.print(JSON.stringify(data));
	if (data.type == "wakeup")
		{
			nf.alert("被唤醒启动");
			d1.print("被唤醒启动");
			
		}
	else if (data.type == "notification")
		{
			nf.alert("被推送启动");
			d1.print("被推送启动");
		}else{
			
			nf.alert("正常启动");
			d1.print("正常启动");
		}
});

app.on("loaded", function () {
    this.openPage("source://view/index.ui");
});

//push.on("bind",function(data, e){
//	nf.alert(data,"bind event");
//});
//
//push.on("message",function(data, e){
//	nf.alert(data,"message event");
//});
//
//push.on("iOSMessage",function(data, e){
//	nf.alert(data,"iOSmessage event");
//});
//
//push.on("notificationClicked",function(data, e){
//	nf.alert(data,"notificationClicked event");
//});
//
//push.on("unbind",function(data, e){
//	nf.alert(data,"unbind event");
//});