var root = ui("$");

root.setMapping({
	"do_label_1.text":"$1",
	"do_label_2.text":"$2"
});