var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var d = sm("do_Device");
var img = ui("do_ImageView_1");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"vibrate","PARAS1":"duration","VALUE1":"default"},
	{template:0,"$tag":1,"METHOD":"vibrate","PARAS1":"duration","VALUE1":"3"},
	{template:0,"$tag":2,"METHOD":"beep","PARAS1":"","VALUE1":""},
	{template:0,"$tag":3,"METHOD":"flash","PARAS1":"status","VALUE1":"on"},
	{template:0,"$tag":4,"METHOD":"flash","PARAS1":"status","VALUE1":"off"},
	{template:0,"$tag":5,"METHOD":"getInfo","PARAS1":"name","VALUE1":"all"},
	{template:0,"$tag":6,"METHOD":"getAllAppInfo","PARAS1":"","VALUE1":""},
	{template:0,"$tag":7,"METHOD":"screenShot"},
	{template:0,"$tag":8,"METHOD":"getLocale"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			d.vibrate({duration:1000});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			d.vibrate({duration:m1v1});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			d.beep({});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			d.flash({status:m3v1});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			d.flash({status:m4v1});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var a = d.getInfo({name:m5v1});
			nf.alert(a);
			deviceone.print(a.OSVersion,"OSVersion");
			deviceone.print(a.dpiV,"dpiV");
			break;
		case 6:
			var b = d.getAllAppInfo();
			nf.alert(b);
			deviceone.print(b.traffic,"traffic");
			break;
		case 7:
			d.screenShot(function(data, e) {
				nf.alert(data);
				//var url1 = data;
				img.source = data;
			});
			break;  
		case 8:
			var locale = d.getLocale();
			deviceone.print(JSON.stringify(locale),"locale");
			break;
	}
});

