var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var cache = sm("do_DataCache");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_r2l"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:1,"$tag":0,"METHOD":"saveData","PARAS1":"key","VALUE1":"key1","PARAS2":"value","VALUE2":"12345abcde你好啊!"},
	{template:0,"$tag":1,"METHOD":"loadData","PARAS1":"key","VALUE1":"key1"},
	{template:1,"$tag":2,"METHOD":"saveData","PARAS1":"key","VALUE1":"key2","PARAS2":"value","VALUE2":"!@#$%^&&**()_+?//\\"},
	{template:0,"$tag":3,"METHOD":"loadData","PARAS1":"key","VALUE1":"key2"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			cache.saveData({key:m0v1, value:m0v2});
			nf.alert("set key1 & value 12345abcde你好啊! ");
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var a = cache.loadData({key:m1v1});
			nf.alert(a);
			break;	
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			cache.saveData({key:m2v1, value:m2v2});
			nf.alert("set key2 & value !@#$%^&&**()_+?//\\ ");		
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var a = cache.loadData({key:m3v1});
			nf.alert(a);
			break;	
	}
});

