var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var dt = sm("do_DateTimePicker");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_r2l"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var myDate=new Date(2000,6,12,12,15,0);
var dd = myDate.getTime();
deviceone.print(dd,"2000");
var myDate=new Date(2015,1,1,1,1,1);
var aa = myDate.getTime();
deviceone.print(aa,"2015");
var myDate=new Date(2020,1,1,1,1,1);
var cc = myDate.getTime();
deviceone.print(cc,"2020");


var data0 =[
	{template:6,"$tag":0,"METHOD":"show","PARAS1":"type","VALUE1":"0","PARAS2":"data","VALUE2":"662659200","PARAS3":"maxDate","VALUE3":"","PARAS4":"minDate","VALUE4":"-639129600","PARAS5":"title","VALUE5":"","PARAS6":"buttons","VALUE6":""},
	{template:6,"$tag":1,"METHOD":"show","PARAS1":"type","VALUE1":"1","PARAS2":"data","VALUE2":aa,"PARAS3":"maxDate","VALUE3":cc,"PARAS4":"minDate","VALUE4":dd,"PARAS5":"title","VALUE5":"","PARAS6":"buttons","VALUE6":""},
	{template:6,"$tag":2,"METHOD":"show","PARAS1":"type","VALUE1":"2","PARAS2":"data","VALUE2":"1218124800","PARAS3":"maxDate","VALUE3":"631195200000","PARAS4":"minDate","VALUE4":"631130400000","PARAS5":"title","VALUE5":"","PARAS6":"buttons","VALUE6":""}
];

listdata.addData(data0);
list1.refreshItems({});


list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			var m0v3 = m0.VALUE3;
			var m0v4 = m0.VALUE4;
			var m0v5 = m0.VALUE5;
			var m0v6 = m0.VALUE6;
			dt.show({type:0,title:"日期时间选择", buttons:""}, function(data, e){
				nf.alert({text:data, title:""}, function(data, e){});
				deviceone.print(data.time,"time");
			});
			
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			var m1v5 = m1.VALUE5;
			var m1v6 = m1.VALUE6;
			dt.show({type:m1v1, data:m1v2, maxDate:m1v3,minDate:m1v4, title:m1v5, buttons:["aaa","bbb"]}, function(data, e){
				nf.alert({text:data, title:""}, function(data, e){});
				deviceone.print(data.time,"time");
			});
			break;	
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			var m2v5 = m2.VALUE5;
			var m2v6 = m2.VALUE6;
			dt.show({type:m2v1, data:m2v2, maxDate:m2v3, minDate:m2v4, title:m2v5, buttons:[]}, function(data, e){
				nf.alert({text:data, title:""}, function(data, e){});
				deviceone.print(data.time,"time");
			});
			break;
	}
});

