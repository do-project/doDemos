var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"cube"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
{template:1,"$tag":0,"METHOD":"alert","PARAS1":"text","VALUE1":"warning","PARAS2":"title","VALUE2":"dangerous"},
{template:3,"$tag":1,"METHOD":"confirm","PARAS1":"text","VALUE1":"are you sure?","PARAS2":"title","VALUE2":"please confirm your choice","PARAS3":"button1text","VALUE3":"yes","PARAS4":"button2text","VALUE4":"no"},
{template:0,"$tag":2,"METHOD":"toast","PARAS1":"text","VALUE1":"12345abcde你好啊！"}

];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			nf.alert({text:m0v1, title:m0v2}, function(data, e){
				//nf.alert(data);
				nf.toast({text:data}, function(data, e){});
				app.closePage({data:"", animationType:""}, function(data, e){});
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			nf.confirm({text:m1v1, title:m1v2, button1text:m1v3, button2text:m1v4}, function(data, e){
				nf.alert(data);
			});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
//			nf.toast({text:m2v1}, function(data, e){
//				nf.alert(data);
//			});
			nf.toast(m2v1, 10, 10)
			break;
	}
});
