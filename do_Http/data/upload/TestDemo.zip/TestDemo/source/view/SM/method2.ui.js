var root = ui("$");

root.setMapping({
	"method1.tag":"$tag",
	"method1.text":"METHOD",
	"paras1.text":"PARAS1",
	"value1.text":"VALUE1",
	"paras2.text":"PARAS2",
	"value2.text":"VALUE2"
});