var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var imgb = sm("do_ImageBrowser");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"page_curl"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var datashow0 = [
	{"source": "data://1.jpg",
     "init": "data://5.jpg"},
    {"source": "data://245.jpg",
     "init": "data://6.jpg"},
    {"source": "data://3.jpg",
     "init": "data://7.jpg"},
    {"source": "http://f.hiphotos.baidu.com/image/pic/item/8d5494eef01f3a29a8b0ef3e9b25bc315d607cc1.jpg",
     "init": "data://5.jpg"},
	{"source": "http://g.hiphotos.baidu.com/image/pic/item/95eef01f3a292df566f096e5be315c6034a8730a.jpg",
   	 "init": "data://5.jpg"}
];

var data0 =[
{template:1,"$tag":0,"METHOD":"show","PARAS1":"data","VALUE1":datashow0,"PARAS2":"index","VALUE2":"0"},
{template:1,"$tag":1,"METHOD":"show","PARAS1":"data","VALUE1":datashow0,"PARAS2":"index","VALUE2":"3"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			imgb.show({data:m0v1, index:m0v2});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			imgb.show({data:m1v1, index:m1v2});
			break;
		
	}
});
