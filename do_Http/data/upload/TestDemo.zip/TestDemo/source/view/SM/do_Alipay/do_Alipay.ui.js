var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var alipayPay = sm("do_Alipay");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"pay","PARAS1":"partner","VALUE1":""}
	
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
//			alipayPay.pay({
//        //rsaPrivate: "MIICXgIBAAKBgQDl926gn9VGsmfScXpmppRYxmQLZfJOiLVNx27Lg6Gn+bkywDUvTgWZUNHotOFcvaD3NdtGDQrw/9VzCc4dF8Gxezdw+r2UFQS8ww7+hrcq+A0TC5nvT90oH7vJ92TK0ib/uNIt7Jnn1iG9WuBXQBqiFg2soHh8ArbU5ysGKPXr8QIDAQABAoGBAKWQKU5tJDB82zBwUI482cq8MmTeZb/Svq0bqxHMWANGT+ZQ6TmAc5l4zVc7epC5WX0BgjeBxmHR3ouvAHyDkQdn1w5YvUndZ9Zf/b69okEDeXqJ3Id8+jLsUqZV+5FqK6iiDDq4vqTr04O1iyU0ya4W43K48eOZCJAYQ2ab54fNAkEA+Dnc8wqApdRl7l7yhHhT3uFwCufypfnrDaGB499Mzw+QdJ0LZnh5XWLQcLjFkSALFTuwBZ0gpsMDumH6mhOwMwJBAO0rLLcf6tG/exHjhDJKOESysrw/+aZNj49Z+FZEy1L1CtPptrR1YSeMT9BOse2/zD4KbqaP6kyaLyHndlQYf0sCQQDKwpEt4e1WB9o/TUVyWcvAqotYDUFSvIN5Pe0Y0wUtufv4lXODf3M7igTTnsqbEf6bmIbe/wt1zKRV8cS/aMerAkBXwdQH5r2C4zFsyx0NZr0vXlgYpCuCR8zJJGdptIbvqVBaXW6Hk69hbN/TmmroKEIw6rdK1pHByoOKLhVwxKfFAkEAwSOulRWhMMxIot5LgRwXUXilo6rFGBIxwXZM6/cM1P2aH4VTElNTA9e/7rd+PboLa7Blvn+umdZUcue99Y8EAg==",
//        rsaPrivate: "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAOjb5fxNITiTLGHJyQCBAZu1Zs3VtS9L5c8GmdO7xWeE8kwiUFAVHwAuNk+5eYOFoIg4SW73uQU92SqhNifZltH/CLWt4c/JgYx93FBfdwWFPOo4OexLZlWJUQPW19pqa18ouV+DzccclJpZ2Lrv9eUE+2hORgAY+4x8lajTK5WVAgMBAAECgYBEIWrGCi8pJW574hVMb3JwA4Bjwx5zCyrfCthhKfRVGIHoIrYK6FMcs2iypNrXz3YrxQQ/Un2w+eqbXXXB7RkCI1InSYNny2kP037GNPDpUcluQu3PMOkm+7oIj3mhjbB0Ua4KAObLaH4qmmos8K/V09F0o9MXCZfGsdyCj+jUdQJBAPaIxLEDl5WLSJrrYk3SIDSBukDOTS9pSNG37ovroo+6YaM+B5P9PBhohQ0fw5K/TkqLkHrBLIsBk1uZRnCHrQ8CQQDxzLaVNC5CV7V69S3xSzPBPbQNvenqyVgA5KhiUvAu7y2HX3HZ73xhTJPbUxGgdrtrsMnHDYohQC5FAN1QKFsbAkA30xB25NFWU4vFSLeh14rjWNzL/+sKaVTL6FJj7J+K3DFvvYQJxrXs8P3v0tl+SUN5LdExeryTXW/4teR1ZsORAkEAo9REUUuNnD25JJpCip6dbmzUNgtbFk1dZx2GSThQrDw56OLuTO9KotIzzAK4irRnwEuEK24tDOJjdzVivhDZyQJBANkyrYk+yVdy4VCD1giNmvtKnLZlmOX0hpdtNc23WyY97hdHUhL380L+qlGOLYAZdQWgdjZqDXnlEnqvFIqb98U=",
//        rsaPublic: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB",
//        partner: "2088911900461427",
//        notifyUrl: "http://notify.msp.hk/notify.htm",
//        tradeNo: "2088101568353491",
//        subject: "商品名称",
//        sellerId: "1215771886@qq.com",
//        totalFee: "0.01",
//        body: "商品body",
//        timeOut: "15d"
//    					},
//    		function (data, e) {
//					nf.alert({text:data, title:"支付结果"}, function(data, e){});
//			});
//			break;
			
			alipayPay.pay({
				rsaPrivate: "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAOjb5fxNITiTLGHJyQCBAZu1Zs3VtS9L5c8GmdO7xWeE8kwiUFAVHwAuNk+5eYOFoIg4SW73uQU92SqhNifZltH/CLWt4c/JgYx93FBfdwWFPOo4OexLZlWJUQPW19pqa18ouV+DzccclJpZ2Lrv9eUE+2hORgAY+4x8lajTK5WVAgMBAAECgYBEIWrGCi8pJW574hVMb3JwA4Bjwx5zCyrfCthhKfRVGIHoIrYK6FMcs2iypNrXz3YrxQQ/Un2w+eqbXXXB7RkCI1InSYNny2kP037GNPDpUcluQu3PMOkm+7oIj3mhjbB0Ua4KAObLaH4qmmos8K/V09F0o9MXCZfGsdyCj+jUdQJBAPaIxLEDl5WLSJrrYk3SIDSBukDOTS9pSNG37ovroo+6YaM+B5P9PBhohQ0fw5K/TkqLkHrBLIsBk1uZRnCHrQ8CQQDxzLaVNC5CV7V69S3xSzPBPbQNvenqyVgA5KhiUvAu7y2HX3HZ73xhTJPbUxGgdrtrsMnHDYohQC5FAN1QKFsbAkA30xB25NFWU4vFSLeh14rjWNzL/+sKaVTL6FJj7J+K3DFvvYQJxrXs8P3v0tl+SUN5LdExeryTXW/4teR1ZsORAkEAo9REUUuNnD25JJpCip6dbmzUNgtbFk1dZx2GSThQrDw56OLuTO9KotIzzAK4irRnwEuEK24tDOJjdzVivhDZyQJBANkyrYk+yVdy4VCD1giNmvtKnLZlmOX0hpdtNc23WyY97hdHUhL380L+qlGOLYAZdQWgdjZqDXnlEnqvFIqb98U=",
		        rsaPublic: "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnxj/9qwVfgoUh/y2W89L6BkRAFljhNhgPdyPuBV64bfQNN1PjbCzkIM6qRdKBoLPXmKKMiFYnkd6rAoprih3/PrQEB/VsW8OoM8fxn67UDYuyBTqA23MML9q1+ilIZwBC2AQ2UBVOrFXfFl75p6/B5KsiNG9zpgmLCUYuLkxpLQIDAQAB",
		        partner: "2088501789961691",
		        notifyUrl: "http://202.85.217.29/mobileapp/pages/alipay/mobileasync.jsp",
		        tradeNo: "DYD201509141429539237",
		        subject: "产品信息",
		        sellerId: "zhifubao_use@cncotton.com",
		        totalFee: "0.01",
		        body: "商品body",
		        timeOut: "15d"
		    					},
		    		function (data, e) {
							nf.alert({text:data, title:"支付结果"}, function(data, e){});
					});
					break;
		}
});

