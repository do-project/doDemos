var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var apple = sm("do_AppleIAP");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:1,"$tag":0,"METHOD":"purchase","PARAS1":"productID","VALUE1":"","PARAS2":"verifyURL","VALUE2":"https://sandbox.itunes.apple.com/verifyReceipt"},
	{template:1,"$tag":1,"METHOD":"purchase","PARAS1":"productID","VALUE1":"","PARAS2":"verifyURL","VALUE2":"https://buy.itunes.apple.com/verifyReceipt"},
	
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			
			break;
		}
});

