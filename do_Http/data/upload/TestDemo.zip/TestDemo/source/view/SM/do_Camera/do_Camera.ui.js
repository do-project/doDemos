var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var camera = sm("do_Camera");
var img = ui("do_imageview_1");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_l2r"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:3,"$tag":0,"METHOD":"capture","PARAS1":"width","VALUE1":"default","PARAS2":"height","VALUE2":"default","PARAS3":"quality","VALUE3":"default","PARAS4":"iscut","VALUE4":"default"},
	{template:3,"$tag":1,"METHOD":"capture","PARAS1":"width","VALUE1":"-1","PARAS2":"height","VALUE2":"-1","PARAS3":"quality","VALUE3":"100","PARAS4":"iscut","VALUE4":"true"},
	{template:3,"$tag":2,"METHOD":"capture","PARAS1":"width","VALUE1":"-1","PARAS2":"height","VALUE2":"-1","PARAS3":"quality","VALUE3":"100","PARAS4":"iscut","VALUE4":"false"},
	{template:3,"$tag":3,"METHOD":"capture","PARAS1":"width","VALUE1":"50","PARAS2":"height","VALUE2":"50","PARAS3":"quality","VALUE3":"100","PARAS4":"iscut","VALUE4":"true"}
	

];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			var m0v3 = m0.VALUE3;
			var m0v4 = m0.VALUE4;
			camera.capture({width:"", height:"", quality:100, iscut:"false"}, function(data, e){
				nf.alert(data);
				img.source = data;
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			camera.capture({width:m1v1, height:m1v2, quality:m1v3, iscut:m1v4}, function(data, e){
				nf.alert(data);
				img.source = data;
			});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			camera.capture({width:m2v1, height:m2v2, quality:m2v3, iscut:m2v4}, function(data, e){
				nf.alert(data);
				img.source = data;
			});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			var m3v4 = m3.VALUE4;
			camera.capture({width:m3v1, height:m3v2, quality:m3v3, iscut:m3v4}, function(data, e){
				nf.alert(data);
				img.source = data;
			});
			break;
		
	}
});

