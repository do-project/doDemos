var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var audio = sm("do_Audio");

var progress1 = ui("progress");
var label = ui("label");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_r2l"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"play","PARAS1":"path","VALUE1":"data://1.mp3"},
	{template:0,"$tag":1,"METHOD":"play","PARAS1":"path","VALUE1":"source://2.mp3"},
	{template:0,"$tag":2,"METHOD":"play","PARAS1":"path","VALUE1":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3"},
	{template:1,"$tag":3,"METHOD":"play","PARAS1":"path","VALUE1":"data://1.mp3","PARAS2":"point","VALUE2":"5000"},
	{template:0,"$tag":4,"METHOD":"pause","PARAS1":"","VALUE1":""},
	{template:0,"$tag":5,"METHOD":"resume","PARAS1":"","VALUE1":""},
	{template:0,"$tag":6,"METHOD":"stop","PARAS1":"","VALUE1":""},
	{template:1,"$tag":7,"METHOD":"play","PARAS1":"path","VALUE1":"data://1.amr","PARAS2":"备注","VALUE2":"音频格式为amr"},
	{template:1,"$tag":8,"METHOD":"play","PARAS1":"path","VALUE1":"data://1.aac","PARAS2":"备注","VALUE2":"音频格式为amr"},
	{template:3,"$tag":9,"METHOD":"startRecord","PARAS1":"path","VALUE1":"data://record/1.mp3","PARAS2":"type","VALUE2":"mp3","PARAS3":"quality","VALUE3":"normal","PARAS4":"limit","VALUE4":"-1"},
	{template:3,"$tag":10,"METHOD":"startRecord","PARAS1":"path","VALUE1":"data://record/2.amr","PARAS2":"type","VALUE2":"amr","PARAS3":"quality","VALUE3":"low","PARAS4":"limit","VALUE4":"1500"},
	{template:3,"$tag":11,"METHOD":"startRecord","PARAS1":"path","VALUE1":"data://record/3.aac","PARAS2":"type","VALUE2":"aac","PARAS3":"quality","VALUE3":"high","PARAS4":"limit","VALUE4":"6000"},
	{template:0,"$tag":12,"METHOD":"stopRecord","PARAS1":"录音结束直接播放录音","VALUE1":""}
	//{template:0,"$tag":13,"METHOD":"stopRecord","PARAS1":"结束录音","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

var a ;

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			audio.play({path:m0v1, point:0});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			audio.play({path:m1v1, point:0});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			audio.play({path:m2v1, point:0});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			//audio.play({path:m3v1, point:m3v2});
			audio.play({path:m3v1, point:5000});
			break;
		case 4:
			var n = audio.pause({});
			//nf.alert({text:n, title:"暂停时播放到第几毫秒"}, function(data, e){});
			label.text = "暂停时播放到第" + n + "毫秒";
			break;
		case 5:
			audio.resume({});
			break;
		case 6:
			audio.stop({});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			audio.play({path:m7v1, point:0});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			audio.play({path:m8v1, point:0});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			var m9v3 = m9.VALUE3;
			var m9v4 = m9.VALUE4;
			var bb = audio.startRecord({path:m9v1, type:m9v2, quality:m9v3, limit:m9v4});
			label.text = "开始录音" + bb;
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			var m10v3 = m10.VALUE3;
			var m10v4 = m10.VALUE4;
			var ss = audio.startRecord({path:m10v1, type:m10v2, quality:m10v3, limit:m10v4});
			label.text = "开始录音" + ss;
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			var m11v3 = m11.VALUE3;
			var m11v4 = m11.VALUE4;
			var vv = audio.startRecord({path:m11v1, type:m11v2, quality:m11v3, limit:m11v4});
			label.text = "开始录音" + vv;
			break;
		case 12:
			a = audio.stopRecord({});
			nf.alert({text:a, title:"返回录音文件保存的目录及文件名"}, function(data, e){});
			break;
	}
});


audio.on("error",function(data, e){
	label.text = "error event is fired";
});
audio.on("playFinished",function(data, e){
	label.text = "playFinished";
});
audio.on("playProgress",function(data, e){
	var ct = data.currentTime;
	var tt = data.totalTime;
	var pv = ct/tt*100;
	progress1.progress = pv;
	label.text = "当前播放进度" +pv;
});
audio.on("recordFinished",function(data, e){
	label.text = "recordFinished event is fired";
	//audio.play({path:a, point:0});
});
audio.on("recordProgress",function(data, e){
	label.text = "当前录音进度" +data;
	progress1.progress = data/1000;
});