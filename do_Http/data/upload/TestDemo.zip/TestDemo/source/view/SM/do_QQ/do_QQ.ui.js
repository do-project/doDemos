var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var qq = sm("do_TencentQQ");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"login","PARAS1":"appId","VALUE1":"1104496001"},//2621561678
	{template:0,"$tag":1,"METHOD":"logout","PARAS1":"","VALUE1":""},
	{template:6,"$tag":2,"METHOD":"shareToQQ","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"0","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test","PARAS7":"audio","VALUE7":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3","PARAS8":"appName","VALUE8":"DeviceOne"},
	{template:6,"$tag":3,"METHOD":"shareToQQ","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"1","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test","PARAS7":"audio","VALUE7":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3","PARAS8":"appName","VALUE8":"DeviceOne"},
	{template:6,"$tag":4,"METHOD":"shareToQQ","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"2","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test","PARAS7":"audio","VALUE7":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3","PARAS8":"appName","VALUE8":"DeviceOne"},
	{template:6,"$tag":5,"METHOD":"shareToQQ","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"3","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test","PARAS7":"audio","VALUE7":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3","PARAS8":"appName","VALUE8":"DeviceOne"},
	{template:5,"$tag":6,"METHOD":"shareToQzone","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"0","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test"},
	{template:5,"$tag":7,"METHOD":"shareToQzone","PARAS1":"appId","VALUE1":"1104496001","PARAS2":"type","VALUE2":"0","PARAS3":"title","VALUE3":"hello","PARAS4":"url","VALUE4":"http://h.hiphotos.baidu.com/zhidao/pic/item/d4628535e5dde7118791079ca6efce1b9d16611c.jpg","PARAS5":"image","VALUE5":"data://4.jpg","PARAS6":"summary","VALUE6":"share test"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			qq.login({appId:m0v1}, function(data, e){
				qq.getUserInfo({expires:data.expires_in, openId:data.openid, token:data.access_token}, function(data, e){
					var a = typeof data;
					nf.alert(a);
					nf.alert(data);
				});
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			qq.logout({}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;	
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			var m2v5 = m2.VALUE5;
			var m2v6 = m2.VALUE6;
			var m2v7 = m2.VALUE7;
			var m2v8 = m2.VALUE8;
			qq.shareToQQ({appId:m2v1, type:m2v2, title:m2v3, url:m2v4, image:m2v5, summary:m2v6, audio:m2v7, appName:m2v8}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			var m3v4 = m3.VALUE4;
			var m3v5 = m3.VALUE5;
			var m3v6 = m3.VALUE6;
			var m3v7 = m3.VALUE7;
			var m3v8 = m3.VALUE8;
			qq.shareToQQ({appId:m3v1, type:m3v2, title:m3v3, url:m3v4, image:m3v5, summary:m3v6, audio:m3v7, appName:m3v8}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			var m4v3 = m4.VALUE3;
			var m4v4 = m4.VALUE4;
			var m4v5 = m4.VALUE5;
			var m4v6 = m4.VALUE6;
			var m4v7 = m4.VALUE7;
			var m4v8 = m4.VALUE8;
			nf.alert(m4v2,"type");
			qq.shareToQQ({appId:m4v1, type:m4v2, title:m4v3, url:m4v4, image:m4v5, summary:m4v6, audio:m4v7, appName:m4v8}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			var m5v3 = m5.VALUE3;
			var m5v4 = m5.VALUE4;
			var m5v5 = m5.VALUE5;
			var m5v6 = m5.VALUE6;
			var m5v7 = m5.VALUE7;
			var m5v8 = m5.VALUE8;
			qq.shareToQQ({appId:m5v1, type:m5v2, title:m5v3, url:m5v4, image:m5v5, summary:m5v6, audio:m5v7, appName:m5v8}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			var m6v3 = m6.VALUE3;
			var m6v4 = m6.VALUE4;
			var m6v5 = m6.VALUE5;
			var m6v6 = m6.VALUE6;
			qq.shareToQzone({appId:m6v1, type:m6v2, title:m6v3, url:m6v4, image:m6v5, summary:m6v6}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			var m7v3 = m7.VALUE3;
			var m7v4 = m7.VALUE4;
			var m7v5 = m7.VALUE5;
			var m7v6 = m7.VALUE6;
			qq.shareToQzone({appId:m7v1, type:m7v2, title:m7v3, url:m7v4, image:m7v5, summary:m7v6}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
	}
});

