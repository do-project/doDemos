var rootview = ui("$");
var page = sm("do_Page");

rootview.setMapping({
	"methodes.text":"METHODES",
	"paras1.text":"PARAS1",
	"touch.text":"ACTION",
	"touch.tag":"PARAS1"
});

var touch = ui("touch");
touch.on("touch",function(data,e){
	page.fire("abc",this.tag);
});

