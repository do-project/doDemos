var app = sm("do_App");
var page = sm("do_Page");
var UM = sm("do_UMengAnalytics");
var nf = sm("do_Notification");




page.on("resume",function(data, e){
	UM.beginPageLog({pageName:"new.ui"});
});

var do_button_1 = ui("do_button_1");
do_button_1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

page.on("pause",function(data, e){
	UM.endPageLog({pageName:"new.ui"});
});

var do_button_2 = ui("do_button_2");
do_button_2.on("touch",function(data, e){
	
	UM.eventLog({id:"touch", data:{}});
//	UM.eventLog({id:"test12", data:{}});
	nf.toast({text:"touch1 event"}, function(data, e){});
});


var do_button_3 = ui("do_button_3");
do_button_3.on("touch",function(data, e){
	UM.eventValueLog({id:"touch1", data:{}, counter:0});
//	UM.eventValueLog({id:"test12", data:{}, counter:0});
	nf.toast({text:"touch2 event "}, function(data, e){});
});
