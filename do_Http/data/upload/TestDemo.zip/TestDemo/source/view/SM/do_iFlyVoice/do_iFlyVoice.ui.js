var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var xf = sm("do_iFlyVoice");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"open","PARAS1":"","VALUE1":""},
	{template:1,"$tag":1,"METHOD":"speak","PARAS1":"text","VALUE1":"DeviceOne是国际领先的跨平台移动应用开发平台","PARAS2":"role","VALUE2":"vixqa"},
	{template:1,"$tag":2,"METHOD":"speak","PARAS1":"text","VALUE1":"I used to rule the world Seas would rise when I gave the word","PARAS2":"role","VALUE2":"catherine"},
	{template:0,"$tag":3,"METHOD":"pause","PARAS1":"","VALUE1":""},
	{template:0,"$tag":4,"METHOD":"resume","PARAS1":"","VALUE1":""},
	{template:0,"$tag":5,"METHOD":"stop","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			xf.open({}, function(data, e){
				var a = typeof data;
				nf.alert({text:a, title:"返回值类型"}, function(data, e){});
				nf.alert({text:data, title:"返回值"}, function(data, e){});
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			xf.speak({text:m1v1, role:m1v2});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			xf.speak({text:m2v1, role:m2v2});
			break;
		case 3:
			xf.pause({});
			break;
		case 4:
			xf.resume({});
			break;
		case 5:
			xf.stop({});
			break;
		}
});

xf.on("begin",function(data, e){
	nf.alert({text:"bengin event is fired", title:""}, function(data, e){});
});
xf.on("finished",function(data, e){
	nf.alert({text:"finished event is fired", title:""}, function(data, e){});
});
xf.on("paused",function(data, e){
	nf.alert({text:"paused event is fired", title:""}, function(data, e){});
});
xf.on("resumed",function(data, e){
	nf.alert({text:"resumed event is fired", title:""}, function(data, e){});
});