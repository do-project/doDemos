var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var vpn = sm("do_SangforVPN");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"login","PARAS1":"host","VALUE1":"202.108.121.92","PARAS2":"username","VALUE2":"test1","PARAS3":"password","VALUE3":"test1","PARAS4":"port","VALUE4":""},
	{template:0,"$tag":1,"METHOD":"speak"}
	
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			var m0v3 = m0.VALUE3;
			var m0v4 = m0.VALUE4;
			vpn.login(m0v1, m0v2, m0v3, m0v4, function(data, e) {
				nf.alert(JSON.stringify(data));
			})
			break;
		case 1:
			vpn.logout(function(data, e) {
				nf.alert(JSON.stringify(data));
			})
			break;
		}
});

xf.on("begin",function(data, e){
	nf.alert({text:"bengin event is fired", title:""}, function(data, e){});
});
xf.on("finished",function(data, e){
	nf.alert({text:"finished event is fired", title:""}, function(data, e){});
});
xf.on("paused",function(data, e){
	nf.alert({text:"paused event is fired", title:""}, function(data, e){});
});
xf.on("resumed",function(data, e){
	nf.alert({text:"resumed event is fired", title:""}, function(data, e){});
});