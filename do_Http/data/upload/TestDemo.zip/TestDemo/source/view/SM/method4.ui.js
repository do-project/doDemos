var root = ui("$");

root.setMapping({
	"method1.tag":"$tag",
	"method1.text":"METHOD",
	"paras1.text":"PARAS1",
	"value1.text":"VALUE1",
	"paras2.text":"PARAS2",
	"value2.text":"VALUE2",
	"paras3.text":"PARAS3",
	"value3.text":"VALUE3",
	"paras4.text":"PARAS4",
	"value4.text":"VALUE4"
});