var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var net = sm("do_Network");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"page_uncurl"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"getStatus","PARAS1":"","VALUE1":""},
	{template:0,"$tag":1,"METHOD":"getIP","PARAS1":"","VALUE1":""},
	{template:0,"$tag":2,"METHOD":"getOperators","PARAS1":"","VALUE1":""},
	{template:0,"$tag":3,"METHOD":"getMACAddress","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var a = net.getStatus({});
			nf.alert(a);
			break;
		case 1:
			var a = net.getIP({});
			nf.alert(a);
			break;	
		case 2:
			var a = net.getOperators({});
			nf.alert(a);	
			break;
		case 3:
			var a1 = net.getMACAddress({});
			nf.alert(a1);	
			break;
		
	}
});

net.on("changed",function(data, e){
	nf.alert(data);
});