var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var ext = sm("do_External");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_t2b"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:2,"$tag":0,"METHOD":"openApp","PARAS1":"wakeupid","VALUE1":"com.tencent.mm","PARAS2":"data","VALUE2":"{'key1':'hello'}","PARAS3":"说明","VALUE3":"唤醒id为com.tencent.mm，可唤醒微信"},
	{template:2,"$tag":1,"METHOD":"openApp","PARAS1":"wakeupid","VALUE1":"com.test.child","PARAS2":"data","VALUE2":"{'key1':'hello'}","PARAS3":"说明","VALUE3":"唤醒id为com.test.child，可唤醒生产环境的http://developer.deviceone.net/apppackage/index/f0baf03b-a42a-4125-b73a-4061751d8081这个包"},
	{template:0,"$tag":2,"METHOD":"openURL","PARAS1":"url","VALUE1":"https://www.baidu.com"},
	{template:0,"$tag":3,"METHOD":"openDial","PARAS1":"number","VALUE1":"10086"},
	{template:0,"$tag":4,"METHOD":"openContact","PARAS1":"","VALUE1":""},
	{template:2,"$tag":5,"METHOD":"openMail","PARAS1":"to","VALUE1":"zhuyu0206@126.com","PARAS2":"subject","VALUE2":"hello child","PARAS3":"body","VALUE3":"hi~"},
	{template:1,"$tag":6,"METHOD":"openSMS","PARAS1":"number","VALUE1":"13661159402","PARAS2":"body","VALUE2":"123abc你好"},
	{template:2,"$tag":7,"METHOD":"openApp","PARAS1":"wakeupid","VALUE1":"wechat:LaunchWechat?target=MainPage","PARAS2":"data","VALUE2":"{'key1':'hello'}","PARAS3":"说明","VALUE3":"唤醒winPhone的微信"},
	{template:0,"$tag":8,"METHOD":"installApp","PARAS1":"path","VALUE1":"data://Gen_Signature_Android221cbf.apk"},
	{template:0,"$tag":9,"METHOD":"openFile","PARAS1":"path","VALUE1":"data://ggg.docx"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			ext.openApp({wakeupid:m0v1, data:m0v2});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			ext.openApp({wakeupid:m1v1, data:m1v2});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			ext.openURL({url:m2v1});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			ext.openDial({number:m3v1});
			break;
		case 4:
			ext.openContact({});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			var m5v3 = m5.VALUE3;
			ext.openMail({to:m5v1, subject:m5v2, body:m5v3});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			ext.openSMS({number:m6v1, body:m6v2});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			ext.openApp({wakeupid:m7v1, data:m7v2});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			ext.installApp({path:m8v1});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			ext.openFile({path:m9v1});
			break;
	}
});

