var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var at = sm("do_AssistiveTouch");
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
//page.on("loaded",function(){
//	at.showView("400,700", "data://atouch.jpg");
//})

var img1 = ui("do_ImageView_1");
var btn1 = ui("do_Button_2");
var btn2 = ui("do_Button_3");

at.on("touch",function(){
	img1.visible = true;
})

img1.on("touch",function(){
	at.hideView();
})

btn1.on("touch",function(){
	at.showView("10,10", "data://atouch.jpg");
	deviceone.print("show");
})
btn2.on("touch",function(){
	at.hideView();
	deviceone.print("hide");
})

