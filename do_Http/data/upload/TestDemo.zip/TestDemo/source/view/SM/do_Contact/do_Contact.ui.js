var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var contact = sm("do_Contact");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

//var data_C = [
//	{'name':'张1','phone':'13922864511','email':'11a@deviceone.com'},
//	{'name':'张2','phone':'13922864522','email':'22b@deviceone.com'},
//	{'name':'张3','phone':'13922864533','email':'33c@deviceone.com'},
//	{'name':'张4','phone':'13922864544','email':'44d@deviceone.com'},
//	{'name':'张5','phone':'13922864555','email':'55e@deviceone.com'},
//	{'name':'张5','phone':'13922864555','email':'55e@deviceone.com'},
//	{'name':'张5','phone':'13922864555','email':'55e@deviceone.com'},
//	{'name':'张6','phone':'13922864566','email':'66f@deviceone.com'}
//]

var data_C = [
          	{'name':'张1','phone':'13922864511','email':'11a@deviceone.com'}
          ]

var data0 =[
	{template:0,"$tag":0,"METHOD":"addData","PARAS1":"paras","VALUE1":"6条数据"},
	{template:0,"$tag":1,"METHOD":"getData","PARAS1":"张/33c/139","VALUE1":"name/email/phone"},
	{template:0,"$tag":2,"METHOD":"getDataById","PARAS1":"id","VALUE1":"3"},
	{template:0,"$tag":3,"METHOD":"updateData","PARAS1":"id","VALUE1":"3","PARAS2":"paras","VALUE2":"修改name"},
	{template:0,"$tag":4,"METHOD":"deleteData","PARAS1":"ids","VALUE1":"3"},
	{template:0,"$tag":5,"METHOD":"deleteAllData","PARAS1":"ids","VALUE1":"all"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			contact.addData(data_C, function(data, e) {
				deviceone.print(JSON.stringify(data),"返回的id");
			})
			break;
		case 1:
			contact.getData("张", ["name"], function(data, e) {
				deviceone.print(JSON.stringify(data),"按name查询");
			})
			contact.getData("33c", ["email"], function(data, e) {
				deviceone.print(JSON.stringify(data),"按email查询");
			})
			contact.getData("139", ["phone"], function(data, e) {
				deviceone.print(JSON.stringify(data),"按phone查询");
			})
			contact.getData(function(data, e) {
				deviceone.print(JSON.stringify(data),"查询全部");
			})
			break;
		case 2:
			contact.getDataById(3, function(data, e) {
				deviceone.print(JSON.stringify(data),"按id=3查询");
			})
			break;
		case 3:
			contact.updateData(123, {'name':'李5','phone':'11111','email':'11c@deviceone.com'}, function(data, e) {
				deviceone.print(data,"是否成功");
				contact.getDataById(123, function(data, e) {
					deviceone.print(JSON.stringify(data),"查询修改id3之后的联系人");
				})
			})
//			contact.getDataById(110, function(data, e) {
//				deviceone.print(JSON.stringify(data),"查询修改id3之后的联系人");
//			})
			break;
		case 4:
			contact.deleteData([3], function(data, e) {
				deviceone.print(data,"是否成功");
			})
			contact.getDataById(3, function(data, e) {
				deviceone.print(JSON.stringify(data),"删除id3后再查询");
			})
			break;
		case 5:
			contact.deleteData(function(data, e) {
				deviceone.print(data,"删除全部是否成功");
			})
			contact.getData(function(data, e) {
				deviceone.print(JSON.stringify(data),"删除全部后再查询");
			})
			break;
		}
});

