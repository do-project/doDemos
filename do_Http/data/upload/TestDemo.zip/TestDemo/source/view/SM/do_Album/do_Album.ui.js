var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var album = sm("do_Album");
var grid = ui("do_gridview_1");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var listdata2 = mm("do_ListData");
grid.bindItems(listdata2);

var data0 =[
{template:3,"$tag":0,"METHOD":"select","PARAS1":"maxCount","VALUE1":"default","PARAS2":"width","VALUE2":"default","PARAS3":"height","VALUE3":"default","PARAS4":"quality","VALUE4":"default"},
{template:3,"$tag":1,"METHOD":"select","PARAS1":"maxCount","VALUE1":"9","PARAS2":"width","VALUE2":"-1","PARAS3":"height","VALUE3":"-1","PARAS4":"quality","VALUE4":"50"},
{template:3,"$tag":2,"METHOD":"select","PARAS1":"maxCount","VALUE1":"12","PARAS2":"width","VALUE2":"-1","PARAS3":"height","VALUE3":"","PARAS4":"quality","VALUE4":"10"},
{template:3,"$tag":3,"METHOD":"select","PARAS1":"maxCount","VALUE1":"3","PARAS2":"width","VALUE2":"","PARAS3":"height","VALUE3":"-1","PARAS4":"quality","VALUE4":"100"},
{template:0,"$tag":4,"METHOD":"save","PARAS1":"说明","VALUE1":"点击gridview里的图片即可保存(空地址)"},
{template:4,"$tag":5,"METHOD":"select","PARAS1":"maxCount","VALUE1":"1","PARAS2":"width","VALUE2":"","PARAS3":"height","VALUE3":"-1","PARAS4":"quality","VALUE4":"100","PARAS5":"iscut","VALUE5":"true"}

];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			var m0v3 = m0.VALUE3;
			var m0v4 = m0.VALUE4;
			album.select({maxCount:1, width:100, height:100, quality:100}, function(data, e){
				nf.alert(data);				
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			album.select({maxCount:m1v1, width:m1v2, height:m1v3, quality:m1v4}, function(data, e){
				for (var i=0;i<=data.length-1;i++){
					var d1 = [{"$1":data[i]}];
					listdata2.addData(d1);
					grid.refreshItems({});
					nf.alert({text:data[i], title:"裁剪后图片保存地址"}, function(data, e){});
					var nm = i+".jpg"
					album.save({path:data[i], name:nm, width:0, height:0, quality:100}, function(data, e){
						nf.alert({text:data, title:"图片是否保存成功"}, function(data, e){});
					});
				}
//				var _data = [];
//				data.map(function(index){
//					_data.push({"do_imageview_1":index});
//					return _data;
//				});
//				listdata2.addData(_data);
//				grid.refreshItems({});
				
			});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			album.select({maxCount:m2v1, width:m2v2, height:m2v3, quality:m2v4}, function(data, e){
				for (var i=0;i<=data.length-1;i++){
					var d1 = [{"$1":data[i]}];
					listdata2.addData(d1);
					grid.refreshItems({});
					nf.alert({text:data[i], title:"裁剪后图片保存地址"}, function(data, e){});
					var nn = i+".jpg"
					album.save({path:data[i], name:nn, width:0, height:0, quality:100}, function(data, e){
						nf.alert({text:data, title:"图片是否保存成功"}, function(data, e){});
					});
				}
			});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			var m3v4 = m3.VALUE4;
			album.select({maxCount:m3v1, width:m3v2, height:m3v3, quality:m3v4}, function(data, e){
				for (var i=0;i<=data.length-1;i++){
					var d1 = [{"$1":data[i]}];
					listdata2.addData(d1);
					grid.refreshItems({});
					nf.alert({text:data[i], title:"裁剪后图片保存地址"}, function(data, e){});
					var nmn = i+".jpg"
					album.save({path:data[i], name:nmn, width:0, height:0, quality:100}, function(data, e){
						nf.alert({text:data, title:"图片是否保存成功"}, function(data, e){});
					});
				}
			});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			var m5v3 = m5.VALUE3;
			var m5v4 = m5.VALUE4;
			var m5v5 = m5.VALUE5;
			album.select(m5v1, m5v2, m5v3, m5v4, m5v5, function(data, e) {
				for (var i=0;i<=data.length-1;i++){
					var d1 = [{"$1":data[i]}];
					listdata2.addData(d1);
					grid.refreshItems({});
					nf.alert({text:data[i], title:"裁剪后图片保存地址"}, function(data, e){});
					var nmn = i+".jpg"
					album.save({path:data[i], name:nmn, width:0, height:0, quality:100}, function(data, e){
						nf.alert({text:data, title:"图片是否保存成功"}, function(data, e){});
					});
				}
			})
			break;
			
	}
});

grid.on("touch",function(data, e){
	//var a1 = listdata.getOne({index:index});
	//deviceone.print(data);
	var p1 = "data://saveimage/";
	var n1 = data+".jpg";
	album.save({path:p1, name:n1, width:-1, height:-1, quality:100}, function(data, e){	
		nf.alert({text:data, title:"保存是否成功"}, function(data, e){});
	});
});
