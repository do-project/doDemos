var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var bd = sm("do_BaiduLocation");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:1,"$tag":0,"METHOD":"start","PARAS1":"model","VALUE1":"high","PARAS2":"isLoop","VALUE2":false},
	{template:1,"$tag":1,"METHOD":"start","PARAS1":"model","VALUE1":"middle","PARAS2":"isLoop","VALUE2":true},
	{template:1,"$tag":2,"METHOD":"start","PARAS1":"model","VALUE1":"low","PARAS2":"isLoop","VALUE2":true},
	{template:0,"$tag":3,"METHOD":"stop","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			bd.start({model:"high", isLoop:"false"});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			bd.start({model:"middle", isLoop:"false"});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			bd.start({model:"low", isLoop:"true"});
			break;	
		case 3:
			bd.stop({});
			deviceone.print("stop location");
			break;
	}
});

bd.on("result",function(data, e){
	//nf.alert({text:data, title:"定位到的位置"}, function(data, e){});
	nf.toast({text:data}, function(data, e){});
	deviceone.print(JSON.stringify(data));
});