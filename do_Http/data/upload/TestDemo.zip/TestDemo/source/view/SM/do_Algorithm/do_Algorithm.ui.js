var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var algo = sm("do_Algorithm");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

//var listdata2 = mm("do_ListData");
//grid.bindItems(listdata2);

var data0 =[
{template:1,"$tag":0,"METHOD":"md5","PARAS1":"type","VALUE1":"string","PARAS2":"value","VALUE2":"123abc!@#"},
{template:1,"$tag":1,"METHOD":"md5","PARAS1":"type","VALUE1":"file","PARAS2":"value","VALUE2":"data://test123/test111.txt"},
{template:2,"$tag":2,"METHOD":"des3","PARAS1":"key","VALUE1":"d9893b98d5ae542ccd206d6b83cb456286044307681abf16","PARAS2":"type","VALUE2":"encrypt","PARAS3":"source","VALUE3":"123456"},
//{template:2,"$tag":3,"METHOD":"des3","PARAS1":"key","VALUE1":"d9893b98d5ae542ccd206d6b83cb456286044307681abf16","PARAS2":"type","VALUE2":"decrypt","PARAS3":"source","VALUE3":"3af4f7fca7cc512122fbed4248ff90a9"},
{template:2,"$tag":3,"METHOD":"des3","PARAS1":"key","VALUE1":"d9893b98d5ae542ccd206d6b83cb456286044307681abf16","PARAS2":"type","VALUE2":"decrypt","PARAS3":"source","VALUE3":"02de2bece7eed6a0"},
{template:1,"$tag":4,"METHOD":"sha1","PARAS1":"type","VALUE1":"uppercase","PARAS2":"value","VALUE2":"123abc!@#"},
{template:1,"$tag":5,"METHOD":"sha1","PARAS1":"type","VALUE1":"lowercase","PARAS2":"value","VALUE2":"123abc!@#"},
{template:2,"$tag":6,"METHOD":"base64","PARAS1":"type","VALUE1":"encode","PARAS2":"sourceType","VALUE2":"string","PARAS3":"source","VALUE3":"123abc!@#"},
{template:2,"$tag":7,"METHOD":"base64","PARAS1":"type","VALUE1":"encode","PARAS2":"sourceType","VALUE2":"file","PARAS3":"source","VALUE3":"data://test.do"},
{template:2,"$tag":8,"METHOD":"base64","PARAS1":"type","VALUE1":"decode","PARAS2":"sourceType","VALUE2":"file","PARAS3":"source","VALUE3":""},
{template:2,"$tag":9,"METHOD":"base64","PARAS1":"type","VALUE1":"decode","PARAS2":"sourceType","VALUE2":"string","PARAS3":"source","VALUE3":"MTIzYWJjIUAj"},
{template:1,"$tag":10,"METHOD":"base64Sync","PARAS1":"type","VALUE1":"encode","PARAS2":"source","VALUE2":"123abc!@#child"},
{template:1,"$tag":11,"METHOD":"base64Sync","PARAS1":"type","VALUE1":"decode","PARAS2":"source","VALUE2":"MTIzYWJjJTIxQCUyM2NoaWxk"},
{template:2,"$tag":12,"METHOD":"des3Sync","PARAS1":"key","VALUE1":"d9893b98d5ae542ccd206d6b83cb456286044307681abf16","PARAS2":"type","VALUE2":"encrypt","PARAS3":"source","VALUE3":"hello world"},
{template:2,"$tag":13,"METHOD":"des3Sync","PARAS1":"key","VALUE1":"d9893b98d5ae542ccd206d6b83cb456286044307681abf16","PARAS2":"type","VALUE2":"decrypt","PARAS3":"source","VALUE3":"02de2bece7eed6a0"},
{template:0,"$tag":14,"METHOD":"md5Sync","PARAS1":"value","VALUE1":"hell oworld12345!@#$"},
{template:1,"$tag":15,"METHOD":"sha1Sync","PARAS1":"type","VALUE1":"uppercase","PARAS2":"value","VALUE2":"12345abcde@#$"},
{template:1,"$tag":16,"METHOD":"sha1Sync","PARAS1":"type","VALUE1":"lowercase","PARAS2":"value","VALUE2":"12345abcde@#$"}

];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			algo.md5(m0v1, m0v2, function(data, e) {
				deviceone.print(data,"md5");
			})
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			algo.md5(m1v1, m1v2, function(data, e) {
				deviceone.print(data,"md5");
			})
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			algo.des3(m2v1, m2v2, m2v3, function(data, e) {
				deviceone.print(data,"des3");
			});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			algo.des3(m3v1, m3v2, m3v3,function(data, e) {
				deviceone.print(data,"des3");
			});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			algo.sha1(m4v1, m4v2, function(data, e) {
				deviceone.print(data,"sha1");
			})
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			algo.sha1(m5v1, m5v2, function(data, e) {
				deviceone.print(data,"sha1");
			})
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			var m6v3 = m6.VALUE3;
			algo.base64(m6v1, m6v2, m6v3, function(data, e) {
				deviceone.print(data,"base64");
			})
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			var m7v3 = m7.VALUE3;
			algo.base64(m7v1, m7v2, m7v3, function(data, e) {
				deviceone.print(data,"base64");
				storage.writeFile("data://base64.txt", data, function(data, e) {
					deviceone.print("encode后文件写入data://base64.txt");
				})
			})
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			var m8v2 = m8.VALUE2;
			var m8v3 = m8.VALUE3;
			storage.readFile("data://base64.txt", function(data, e) {
				algo.base64(m8v1, m8v2, data, function(data, e) {
					deviceone.print(data,"base64");
				})
			})
//			algo.base64(m8v1, m8v2, m8v3, function(data, e) {
//				deviceone.print(data,"base64");
//			})
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			var m9v3 = m9.VALUE3;
			algo.base64(m9v1, m9v2, m9v3, function(data, e) {
				deviceone.print(data,"base64");
			})
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			var basesync1 = algo.base64Sync(m10v1, m10v2);
			deviceone.print(basesync1,"base64Sync");
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			var basesync2 = algo.base64Sync(m11v1, m11v2);
			deviceone.print(basesync2,"base64Sync");
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var m12v2 = m12.VALUE2;
			var m12v3 = m12.VALUE3;
			var des3sync1 = algo.des3Sync(m12v1, m12v2, m12v3);
			deviceone.print(des3sync1,"des3Sync");
			break;
		case 13:
			var m13 = listdata.getOne(13);
			var m13v1 = m13.VALUE1;
			var m13v2 = m13.VALUE2;
			var m13v3 = m13.VALUE3;
			var des3sync2 = algo.des3Sync(m13v1, m13v2, m13v3);
			deviceone.print(des3sync2,"des3Sync");
			break;
		case 14:
			var m14 = listdata.getOne(14);
			var m14v1 = m14.VALUE1;
			var md5sync1 = algo.md5Sync(m14v1)
			deviceone.print(md5sync1,"md5Sync");
			break;
		case 15:
			var m15 = listdata.getOne(15);
			var m15v1 = m15.VALUE1;
			var m15v2 = m15.VALUE2;
			var sha1sync1 = algo.sha1Sync(m15v1, m15v2);
			deviceone.print(sha1sync1,"sha1Sync");
			break;
		case 16:
			var m16 = listdata.getOne(16);
			var m16v1 = m16.VALUE1;
			var m16v2 = m16.VALUE2;
			var sha1sync2 = algo.sha1Sync(m16v1, m16v2);
			deviceone.print(sha1sync2,"md5Sync");
			break;
	}
});

