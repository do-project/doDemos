var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var push = sm("do_BaiduPush");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_t2b"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"startWork","PARAS1":"","VALUE1":""},
	{template:0,"$tag":1,"METHOD":"stopWork","PARAS1":"","VALUE1":""},
	{template:0,"$tag":2,"METHOD":"getIconBadgeNumber","PARAS1":"","VALUE1":""},
	{template:0,"$tag":3,"METHOD":"setIconBadgeNumber","PARAS1":"quantity","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			push.startWork({});
			nf.alert("BaiduPush has been started");
			break;
		case 1:
			push.stopWork({});
			nf.alert("BaiduPush has been stopped");
			break;
		case 2:
			var quantity = push.getIconBadgeNumber();
			nf.alert(quantity,"未读消息数量");
			break;
		case 3:
			var quantity1 = push.getIconBadgeNumber();
			push.setIconBadgeNumber(0);
			nf.toast("设置未读消息数量");
			break;
	}
});

