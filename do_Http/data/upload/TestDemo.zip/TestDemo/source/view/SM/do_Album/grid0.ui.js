var root = ui("$");

root.setMapping({
	"do_imageview_1.source":"$1"
});