var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var UM = sm("do_UMengAnalytics");

page.on("resume",function(data, e){
	UM.beginPageLog({pageName:""});
});

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"beginPageLog","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			app.openPage("source://view/SM/do_UMengAnalytics/new.ui");
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			hx.enterChat({username:m1v1, userNickname:m1v2, userIcon:m1v3, myIcon:m1v4});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			hx.logout({});
			nf.toast("logout successed!");
			break;	
	}
});

page.on("resume",function(data, e){

});