var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var wx = sm("do_TencentWX");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"fade"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"login","PARAS1":"appId","VALUE1":"wx7589880f174273b5"},
	{template:7,"$tag":1,"METHOD":"share","PARAS1":"appId","VALUE1":"wx7589880f174273b5","PARAS2":"scene","VALUE2":"0","PARAS3":"type","VALUE3":"0","PARAS4":"title","VALUE4":"share test","PARAS5":"content","VALUE5":"hello world","PARAS6":"url","VALUE6":"http://www.deviceone.net","PARAS7":"image","VALUE7":"data://1.jpg","PARAS8":"audio","VALUE8":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3"},
	{template:7,"$tag":2,"METHOD":"share","PARAS1":"appId","VALUE1":"wx7589880f174273b5","PARAS2":"scene","VALUE2":"1","PARAS3":"type","VALUE3":"1","PARAS4":"title","VALUE4":"share test","PARAS5":"content","VALUE5":"hello world","PARAS6":"url","VALUE6":"http://www.deviceone.net","PARAS7":"image","VALUE7":"data://1.jpg","PARAS8":"audio","VALUE8":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3"},
	{template:7,"$tag":3,"METHOD":"share","PARAS1":"appId","VALUE1":"wx7589880f174273b5","PARAS2":"scene","VALUE2":"0","PARAS3":"type","VALUE3":"2","PARAS4":"title","VALUE4":"share test","PARAS5":"content","VALUE5":"hello world","PARAS6":"url","VALUE6":"http://www.deviceone.net","PARAS7":"image","VALUE7":"data://1.jpg","PARAS8":"audio","VALUE8":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3"},
	{template:6,"$tag":4,"METHOD":"pay","PARAS1":"appId","VALUE1":"wx7589880f174273b5","PARAS2":"partnerId","VALUE2":"1245331002","PARAS3":"prepayId","VALUE3":"wx201507131839000ef4c664c80583333716","PARAS4":"package","VALUE4":"Sign=WXPay","PARAS5":"nonceStr","VALUE5":"e7a0ac723159df05cb1edaa7683e1a53","PARAS6":"timeStamp","VALUE6":"1436783943","PARAS7":"sign","VALUE7":"65DCF55F12B35C2081A29F513297F2A0"}
	
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			wx.login({appId:m0v1}, function(data, e){
				var a = typeof data;
				nf.alert(a);
				nf.alert(data);
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			var m1v5 = m1.VALUE5;
			var m1v6 = m1.VALUE6;
			var m1v7 = m1.VALUE7;
			var m1v8 = m1.VALUE8;
			wx.share({appId:m1v1, scene:m1v2, type:m1v3, title:m1v4, content:m1v5, url:m1v6, image:m1v7, audio:m1v8}, function(data, e){
				nf.alert({text:data, title:"分享返回结果"}, function(data, e){});
			});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			var m2v5 = m2.VALUE5;
			var m2v6 = m2.VALUE6;
			var m2v7 = m2.VALUE7;
			var m2v8 = m2.VALUE8;
			wx.share({appId:m2v1, scene:m2v2, type:m2v3, title:m2v4, content:m2v5, url:m2v6, image:m2v7, audio:m2v8}, function(data, e){
				nf.alert({text:data, title:"分享返回结果"}, function(data, e){});
			});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			var m3v4 = m3.VALUE4;
			var m3v5 = m3.VALUE5;
			var m3v6 = m3.VALUE6;
			var m3v7 = m3.VALUE7;
			var m3v8 = m3.VALUE8;
			wx.share({appId:m3v1, scene:m3v2, type:m3v3, title:m3v4, content:m3v5, url:m3v6, image:m3v7, audio:m3v8}, function(data, e){
				nf.alert({text:data, title:"分享返回结果"}, function(data, e){});
			});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			var m4v3 = m4.VALUE3;
			var m4v4 = m4.VALUE4;
			var m4v5 = m4.VALUE5;
			var m4v6 = m4.VALUE6;
			var m4v7 = m4.VALUE7;
			wx.pay({appId:m4v1, partnerId:m4v2, prepayId:m4v3, package:m4v4, nonceStr:m4v5, timeStamp:m4v6, sign:m4v7}, function(data, e){
				nf.alert({text:data, title:"支付返回结果"}, function(data, e){});
			});
			break;
	}
});
