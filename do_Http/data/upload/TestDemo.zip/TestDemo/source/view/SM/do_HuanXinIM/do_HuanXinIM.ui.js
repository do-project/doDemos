var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var hx = sm("do_HuanXinIM");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"fade"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"login","PARAS1":"username","VALUE1":"123","PARAS2":"password","VALUE2":"123"},
	{template:5,"$tag":1,"METHOD":"enterChat","PARAS1":"userID","VALUE1":"1234","PARAS2":"userNick","VALUE2":"tonny","PARAS3":"userIcon","VALUE3":"http://f.hiphotos.baidu.com/image/pic/item/d000baa1cd11728b2af3ee2bcafcc3cec2fd2cd8.jpg","PARAS4":"selfNick","VALUE4":"child","PARAS5":"selfIcon","VALUE5":"http://mock.deviceone.net/wanda_data/images/test.png","PARAS6":"tag","VALUE6":"123abc你好"},
	{template:0,"$tag":2,"METHOD":"logout","PARAS1":"","VALUE1":""},
	{template:0,"$tag":3,"METHOD":"login","PARAS1":"username","VALUE1":"1234","PARAS2":"password","VALUE2":"1234"},
	{template:5,"$tag":4,"METHOD":"enterChat","PARAS1":"userID","VALUE1":"123","PARAS2":"userNick","VALUE2":"child","PARAS3":"userIcon","VALUE3":"http://www.uimaker.com/uploads/allimg/111124/1_111124092546_1.png","PARAS4":"selfNick","VALUE4":"tonnt","PARAS5":"selfIcon","VALUE5":"http://f.hiphotos.baidu.com/image/pic/item/d000baa1cd11728b2af3ee2bcafcc3cec2fd2cd8.jpg","PARAS6":"tag","VALUE6":"你好abc123"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			hx.login({username:m0v1, password:m0v1}, function(data, e){
				nf.alert({text:data, title:""}, function(data, e){});
			});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			var m1v5 = m1.VALUE5;
			var m1v6 = m1.VALUE6;
			hx.enterChat({userID:m1v1, userNick:m1v2, userIcon:m1v3, selfNick:m1v4, selfIcon:m1v5, tag:m1v6});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			hx.logout({});
			nf.toast("logout successed!");
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			hx.login({username:m3v1, password:m3v1}, function(data, e){
				nf.alert({text:data, title:""}, function(data, e){});
			});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			var m4v3 = m4.VALUE3;
			var m4v4 = m4.VALUE4;
			var m4v5 = m4.VALUE5;
			var m4v6 = m4.VALUE6;
			hx.enterChat({userID:m4v1, userNick:m4v2, userIcon:m4v3, selfNick:m4v4, selfIcon:m4v5, tag:m4v6});
			break;
	}
});

hx.on("connection",function(data, e){
	nf.alert(data);
});

hx.on("receive",function(data, e){
	//nf.alert(data);
	deviceone.print(JSON.stringify(data));
});

hx.on("chatStatusChanged",function(data, e){
	//nf.alert({text:data, title:"聊天状态"}, function(data, e){});
	nf.toast({text:data}, function(data, e){});
});