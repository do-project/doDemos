var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var audio = sm("do_AudioPlay");

var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

/***********************/
var list2 = ui("list2");
var listdata = mm("do_ListData");
list2.bindItems(listdata);

var data2 = [
	{template:0,"METHODES":"play","PARAS1":"data://1.mp3","ACTION":"play"},
	{template:0,"METHODES":"","PARAS1":"source://2.mp3","ACTION":"play"},
	{template:0,"METHODES":"","PARAS1":"http://staff2.ustc.edu.cn/~wdw/softdown/index.asp/0042515_05.ANDY.mp3","ACTION":"play"},
	{template:1,"METHODES":"pause","PARAS1":"","PARAS2":"","ACTION":"pause"},
	{template:1,"METHODES":"stop","PARAS1":"","PARAS2":"","ACTION":"stop"}
];

listdata.addData(data2);
list2.refreshItems({});

/**********************/
//page.on("abc",function(data,e){
//	//audio.play(data,0);
//	//deviceone.print(data);
//});
list2.on("touch",function(index){
	var ld = listdata.getOne(index);
//	var play = ld.METHODES;
//	var p1 = ld.PARAS1;
//	//deviceone.print(m);
//	audio.play(p1);
//	var pause = listdata.getOne(3);
//	var m2 = pause.METHODES
//	audio.m2;
	var i = ld.template;
	switch (i){
	case 0:
		deviceone.print("play");
		break;
	case 1:
		deviceone.print("pause");
		break;
	}
});