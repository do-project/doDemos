//related to scale.ui
var app = sm("do_App");

ui("do_Button_1").on("touch",function(){
	app.closePage();
})

