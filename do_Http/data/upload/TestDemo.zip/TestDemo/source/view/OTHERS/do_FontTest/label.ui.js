var app = sm("do_App");

var do_imageview_1 = ui("do_imageview_1");
do_imageview_1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});
