
ui("$").setMapping({
	"img.source":"$img",
	"alayout.tag":"$tag",
	"label.text":"$txt"	
})

