/**********************************************
 * Author : @Author
 * Timestamp : @Timestamp
 **********************************************/
//var nf = sm("Notification");

var app = sm("do_App");
var _global = sm("do_Global");


var button = ui("button");
button.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/do_FontTest/button.ui");
});

var base = ui("base");
base.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/do_FontTest/label.ui");
});

var base_1 = ui("base_1");
base_1.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/do_FontTest/textbox.ui");
});

var do_button_1 = ui("do_button_1");
do_button_1.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/do_FontTest/textfield.ui");
});

var do_button_8 = ui("do_button_8");
do_button_8.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});
