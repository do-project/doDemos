/**********************************************
 * Author : @zhuyu
 * Timestamp : @Timestamp
 **********************************************/
var app = sm("do_App");
var page = sm("do_Page");
var nf = sm("do_Notification");


var do_button_1 = ui("do_button_1");
do_button_1.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/webview/manage.ui");
});

var do_button_2 = ui("do_button_2");
do_button_2.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/webview/manage1.ui");
});

var do_button_3 = ui("do_button_3");
do_button_3.on("touch",function(data, e){
	app.openPage("source://view/OTHERS/webview/manage2.ui");
});
