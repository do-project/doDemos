/**********************************************
 * Author : @Author
 * Timestamp : @Timestamp
 **********************************************/
var app = sm("do_App");
//var ext = require("ext");
 
var label1 = ui("do_label_1");
var label2 = ui("do_label_2");
var label3 = ui("do_label_3");
var label4 = ui("do_label_4");
var label5 = ui("do_label_5");
var do_label_4_1 = ui("do_label_4_1");

//1
var alayout_1 = ui("alayout_1");
alayout_1.on("touch",function(data, e){
	var ALayout_1 = ui("ALayout_1");
	ALayout_1.on("touch",function(data, e){
		label5.text = "touch alayout 1";
	});
	label1.text = (label1.text*1+1)+"";
});
var alayout_1_off = ui("alayout_1_off");
alayout_1_off.on("touch",function(data, e){
	var ALayout_1 = ui("ALayout_1");
	ALayout_1.off({"name":"touch"});
	var aaa = (label1.text*1)-1;
	aaa = aaa <= 0 ? 0 : aaa ; 
	label1.text = aaa;
});

//2
var alayout_2 = ui("alayout_2");
alayout_2.on("touch",function(data, e){
	var do_alayout_2 = ui("do_alayout_2");
	do_alayout_2.on("touch",function(data, e){
		label5.text = "touch alayout 2";
	});
	label2.text = (label2.text*1+1)+"";
});
var alayout_2_off = ui("alayout_2_off");
alayout_2_off.on("touch",function(data, e){
	var do_alayout_2 = ui("do_alayout_2");
	do_alayout_2.off({"name":"touch"});
	var aaa = (label2.text*1)-1;
	aaa = aaa <= 0 ? 0 : aaa ; 
	label2.text = aaa;
});

//3
var alayout_3 = ui("alayout_3");
alayout_3.on("touch",function(data, e){
	var do_alayout_3 = ui("do_alayout_3");
	do_alayout_3.on("touch",function(data, e){
		label5.text = "touch alayout 3";
	});
	label3.text = (label3.text*1+1)+"";
});
var alayout_3_off = ui("alayout_3_off");
alayout_3_off.on("touch",function(data, e){
	var do_alayout_3 = ui("do_alayout_3");
	do_alayout_3.off({"name":"touch"});
	var aaa = (label3.text*1)-1;
	aaa = aaa <= 0 ? 0 : aaa ; 
	label3.text = aaa;
});



//4
var alayout_4 = ui("alayout_4");
alayout_4.on("touch",function(data, e){
	var button = ui("do_button_10");
	button.on("touch",function(data, e){
		label5.text = "button";
	});
	label4.text = (label4.text*1+1)+"";
});

var alayout_4_off = ui("alayout_4_off");
alayout_4_off.on("touch",function(data, e){
	var button = ui("do_button_10");
	button.off({"name":"touch"});
	var aaa = (label4.text*1)-1;
	aaa = aaa <= 0 ? 0 : aaa ; 
	label4.text = aaa;
});



var do_button_9 = ui("do_button_9");
do_button_9.on("touch",function(data, e){
	label5.text = "xxxx";
});

var do_textbox_1 = ui("do_textbox_1");
do_textbox_1.on("changed",function(data, e){
	label5.text = "button touch event fired";
	//log("text changed event fired");
});

var do_button_12 = ui("do_button_12");
do_button_12.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var do_button_14 = ui("do_button_14");
do_button_14.on("touch",function(data, e){
	var do_imageview_1 = ui("do_imageview_1");
	do_imageview_1.enabled = true ;
	do_imageview_1.on("touch",function(data, e){		
		label5.text = "imageview touched";
	});
	do_label_4_1.text = (do_label_4_1.text*1+1)+"";
});


do_textbox_1.on("touch",function(data, e){
	label5.text = "button touched";
});

var do_button_13 = ui("do_button_13");
do_button_13.on("touch",function(data, e){
	var do_imageview_1 = ui("do_imageview_1");
	do_imageview_1.enabled = false ;
	do_imageview_1.on("touch",function(data, e){		
		label5.text = "imageview touched cancel";
	});
	var aaa = (do_label_4_1.text*1)-1;
	aaa = aaa <= 0 ? 0 : aaa ; 
	do_label_4_1.text = aaa;
});
