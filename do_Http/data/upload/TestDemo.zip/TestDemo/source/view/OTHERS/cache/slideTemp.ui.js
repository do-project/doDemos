//related to slideTemp.ui
var rootview = ui("$");

rootview.setMapping({
	"tag":"$id"
})

var listview = ui("listview");
var listdata = mm("do_ListData");
listview.bindItems(listdata);

//list的数据
var allData = [
    {template:0,"$img":"data://3.jpg","$txt":"0","$tag":"0"},
    {template:0,"$img":"data://0.jpg","$txt":"1","$tag":"0"},
	{template:0,"$img":"data://1.jpg","$txt":"2","$tag":"0"},
    {template:0,"$img":"data://0.jpg","$txt":"3","$tag":"0"},
	{template:0,"$img":"data://1.jpg","$txt":"4","$tag":"0"},
	{template:0,"$img":"data://4.jpg","$txt":"0","$tag":"1"},
	{template:0,"$img":"data://5.jpg","$txt":"1","$tag":"1"},
	{template:0,"$img":"data://4.jpg","$txt":"2","$tag":"1"},
	{template:0,"$img":"data://5.jpg","$txt":"3","$tag":"1"},
	{template:0,"$img":"data://4.jpg","$txt":"4","$tag":"1"},
	{template:0,"$img":"data://4.jpg","$txt":"0","$tag":"2"},
	{template:0,"$img":"data://5.jpg","$txt":"1","$tag":"2"},
	{template:0,"$img":"data://7.jpg","$txt":"2","$tag":"2"},
	{template:0,"$img":"data://5.jpg","$txt":"3","$tag":"2"},
	{template:0,"$img":"data://7.jpg","$txt":"4","$tag":"2"},
	{template:1,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:1,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"4","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"0","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"1","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"2","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"3","$tag":"3"},
	{template:0,"$img":"data://9.jpg","$txt":"4","$tag":"3"}
];

rootview.on("dataRefreshed",function(){
	listdata.removeAll();
	allData.forEach(function(v){
		if(v["$tag"] == rootview.tag)
			listdata.addOne(v);
	})
	listview.refreshItems();
})


