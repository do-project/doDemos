//related to encode.ui
var app = sm("do_App");
var sto = sm("do_Storage");
var lab = ui("do_Label_1");

ui("do_Button_1").on("touch",function(){
	app.closePage();
})

ui("read").on("touch",function(){
	sto.readFile("data://security/mm.txt", function(data, e) {
		lab.text = data;
	})
})
ui("write").on("touch",function(){
	sto.writeFile("data://security/mm2.txt", "deviceone12345", function(data, e) {
		sto.readFile("data://security/mm2.txt", function(data, e) {
		   lab.text = data;
	})
	})
})
