var app = sm("do_App");
var img = ui("img1");
var nf = sm("do_Notification");

img.on("touch",function(){
	app.closePage();	
})

var slide = ui("do_SlideView_1");
var listdata = mm("do_ListData");
slide.bindItems(listdata);

var data0 = [
 	{template:0,"$id":"0"},
 	{template:0,"$id":"1"},
 	{template:0,"$id":"2"},
 	{template:1,"$id":"3"},
 	{template:1,"$id":"4"},
];

listdata.addData(data0);
slide.refreshItems();

slide.on("indexChanged",function(index){
	nf.toast(index);
})

