var app = sm("do_App");
var page = sm("do_Page");
var nf = sm("do_Notification");

var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

/************************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

/************************/
var pagedata = page.getData({});
//var a = pagedata.$tag;
//nf.alert(a);

/************************/
var storage = sm("do_Storage");
storage.readFile("data://idata.json", function(data, e){
	//var a = JSON.parse(data.content); readfile没有去掉data节点的content和length时
	//var a = data;
	//var b = a.CORE[0].MSG;
	//var a = data[pagedata.$tag]
	//nf.alert(a);
	listdata.addData(data[pagedata.$tag]);
	list1.refreshItems({});
});

list1.on("touch",function(index){
	var ld = listdata.getOne(index);
	var type = ld.TYPE;
	var name = ld.NAME; 
	var name1 = ld.NAME;
	app.openPage("source://view/" +type+ "/"+name1+"/" +name+".ui",name);
});
