var root = ui("$");

root.setMapping({
	"name.text":"NAME",
	"msg.text":"MSG"
});