var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/

/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:1,"$tag":0,"METHOD":"closePage","PARAS1":"data","VALUE1":"1a你!","PARAS2":"animationType","VALUE2":"slide_l2r"},
	{template:1,"$tag":1,"METHOD":"closePage","PARAS1":"data","VALUE1":"2b好@","PARAS2":"animationType","VALUE2":"slide_r2l"},
	{template:1,"$tag":2,"METHOD":"closePage","PARAS1":"data","VALUE1":"3c吗#","PARAS2":"animationType","VALUE2":"slide_b2t"},
	{template:1,"$tag":3,"METHOD":"closePage","PARAS1":"data","VALUE1":"4d开￥","PARAS2":"animationType","VALUE2":"slide_t2b"},
	{template:1,"$tag":4,"METHOD":"closePage","PARAS1":"data","VALUE1":"5c发%","PARAS2":"animationType","VALUE2":"push_l2r"},
	{template:1,"$tag":5,"METHOD":"closePage","PARAS1":"data","VALUE1":"6e者……","PARAS2":"animationType","VALUE2":"push_r2l"},
	{template:1,"$tag":6,"METHOD":"closePage","PARAS1":"data","VALUE1":"7f中&","PARAS2":"animationType","VALUE2":"push_b2t"},
	{template:1,"$tag":7,"METHOD":"closePage","PARAS1":"data","VALUE1":"8g心*","PARAS2":"animationType","VALUE2":"push_t2b"},
	{template:1,"$tag":8,"METHOD":"closePage","PARAS1":"data","VALUE1":"9h组（","PARAS2":"animationType","VALUE2":"fade"},
	{template:1,"$tag":9,"METHOD":"closePage","PARAS1":"data","VALUE1":"10i件）","PARAS2":"animationType","VALUE2":"page_curl"},
	{template:1,"$tag":10,"METHOD":"closePage","PARAS1":"data","VALUE1":"11j商——","PARAS2":"animationType","VALUE2":"page_uncurl"},
	{template:1,"$tag":11,"METHOD":"closePage","PARAS1":"data","VALUE1":"12k店+","PARAS2":"animationType","VALUE2":"cube"},
	{template:2,"$tag":12,"METHOD":"closePage","PARAS1":"data","VALUE1":"12k店+","PARAS2":"animationType","VALUE2":"cube","PARAS3":"layer","VALUE3":""},
	{template:2,"$tag":13,"METHOD":"closePage","PARAS1":"data","VALUE1":"12k店+","PARAS2":"animationType","VALUE2":"cube","PARAS3":"layer","VALUE3":"4"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var m0v2 = m0.VALUE2;
			app.closePage({data:m0v1, animationType:m0v2}, function(data, e){});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			app.closePage({data:m1v1, animationType:m1v2}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			app.closePage({data:m2v1, animationType:m2v2}, function(data, e){});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			app.closePage({data:m3v1, animationType:m3v2}, function(data, e){});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			app.closePage({data:m4v1, animationType:m4v2}, function(data, e){});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			app.closePage({data:m5v1, animationType:m5v2}, function(data, e){});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			app.closePage({data:m6v1, animationType:m6v2}, function(data, e){});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			app.closePage({data:m7v1, animationType:m7v2}, function(data, e){});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			var m8v2 = m8.VALUE2;
			app.closePage({data:m8v1, animationType:m8v2}, function(data, e){});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			app.closePage({data:m9v1, animationType:m9v2}, function(data, e){});
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			app.closePage({data:m10v1, animationType:m10v2}, function(data, e){});
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			app.closePage({data:m11v1, animationType:m11v2}, function(data, e){});
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var m12v2 = m12.VALUE2;
			var m12v3 = m12.VALUE3;
			app.closePage({data:m12v1, animationType:m12v2,layer:m12v3}, function(data, e){});
			break;
		case 13:
			var m13 = listdata.getOne(13);
			var m13v1 = m13.VALUE1;
			var m13v2 = m13.VALUE2;
			var m13v3 = m13.VALUE3;
			app.closePage({data:m13v1, animationType:m13v2,layer:m13v3}, function(data, e){});
			break;
	}
});

var pagedata = page.getData({});
nf.alert(pagedata);

app.on("loaded",function(data, e){
	nf.alert("loaded event is fired");
});
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});
