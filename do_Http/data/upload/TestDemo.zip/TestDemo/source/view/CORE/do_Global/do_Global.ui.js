var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var global = sm("do_Global");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"getTime","PARAS1":"format","VALUE1":""},
	{template:0,"$tag":1,"METHOD":"getTime","PARAS1":"format","VALUE1":"yyyy-MM-dd"},
	{template:0,"$tag":2,"METHOD":"getTime","PARAS1":"format","VALUE1":"hh-mm-ss"},
	{template:0,"$tag":3,"METHOD":"getWakeupID","PARAS1":"","VALUE1":""},
	{template:0,"$tag":4,"METHOD":"getVersion","PARAS1":"status","VALUE1":"off"},
	{template:0,"$tag":5,"METHOD":"setMemory","PARAS1":"key","VALUE1":"key1","PARAS2":"value","VALUE2":"123abc你好啊！"},
	{template:0,"$tag":6,"METHOD":"getMemory","PARAS1":"key","VALUE1":"key1"},
	{template:0,"$tag":7,"METHOD":"setMemory","PARAS1":"key","VALUE1":"key2","PARAS2":"value","VALUE2":"@#$%^&*&%$$"},
	{template:0,"$tag":8,"METHOD":"getMemory","PARAS1":"key","VALUE1":"key2"},
	{template:0,"$tag":9,"METHOD":"exit","PARAS1":"","VALUE1":""},
	{template:0,"$tag":10,"METHOD":"install","PARAS1":"src","VALUE1":"data://helloworld.zip"},
	{template:0,"$tag":11,"METHOD":"setToPasteboard","PARAS1":"data","VALUE1":"你好啊data://helloworld.zip++djdjeif#$%^&"},
	{template:0,"$tag":12,"METHOD":"setToPasteboard","PARAS1":"data","VALUE1":"deviceone，为科技而改变"},
	{template:0,"$tag":13,"METHOD":"getFromPasteboard"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var a = global.getTime({format:""});
			nf.alert(a);
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var b = global.getTime({format:m1v1});
			nf.alert(b);
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var c = global.getTime({format:m2v1});
			nf.alert(c);
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var d = global.getWakeupID({});
			nf.alert(d);
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var e = global.getVersion({});
			nf.alert(e);
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			global.setMemory({key:m5v1, value:m5v2});
			nf.alert("setmemory successed");
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var f = global.getMemory({key:m6v1});
			nf.alert(f);
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			global.setMemory({key:m7v1, value:m7v2});
			nf.alert("setmemory successed");
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			var g = global.getMemory({key:m8v1});
			nf.alert(g);
			break;
		case 9:
			global.exit();
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			global.install({src:m10v1}, function(data, e){
				nf.alert("install successed");
			});
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			global.setToPasteboard({data:m11v1});
			nf.alert({text:"内容拷贝到粘贴板", title:""}, function(data, e){});
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			global.setToPasteboard({data:m12v1});
			nf.alert({text:"new内容拷贝到粘贴板", title:""}, function(data, e){});
			break;
		case 13:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var dd = global.getFromPasteboard();
			nf.alert({text:dd, title:"从粘贴板获取的内容"}, function(data, e){});
			break;
	}
});


global.on("background",function(data, e){
	nf.alert("background event is fired");
});
global.on("foreground",function(data, e){
	nf.alert("foreground event is fired");
});

global.on("broadcast",function(data, e){
	var c = typeof data;
	nf.alert(c);
	nf.alert(JSON.stringify(data));
});