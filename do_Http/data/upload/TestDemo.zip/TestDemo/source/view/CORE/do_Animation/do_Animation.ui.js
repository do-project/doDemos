var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var anitest = mm("do_Animation");

var btn1 = ui("btn1");
var l1 = ui("lst1");
var tb1 = ui("tb1");
var web1 = ui("web1");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
{template:1,"$tag":0,"METHOD":"alpha1","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"alpha"},
{template:1,"$tag":1,"METHOD":"alpha2","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"alpha"},
{template:1,"$tag":2,"METHOD":"transfer1","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"transfer"},
{template:1,"$tag":3,"METHOD":"transfer2","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"transfer"},
{template:1,"$tag":4,"METHOD":"scale1","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"scale"},
{template:1,"$tag":5,"METHOD":"scale2","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"scale"},
{template:1,"$tag":6,"METHOD":"rotate1","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"rotate"},
{template:1,"$tag":7,"METHOD":"rotate2","PARAS1":"data","VALUE1":"","PARAS2":"id","VALUE2":"rotate"},
{template:0,"$tag":8,"METHOD":"综合","PARAS1":"data","VALUE1":""},
{template:2,"$tag":9,"METHOD":"on","PARAS1":"name","VALUE1":"name1","PARAS2":"data","VALUE2":"abc123","PARAS3":"delay","VALUE3":"-1"},
{template:1,"$tag":10,"METHOD":"fire","PARAS1":"name","VALUE1":"name1","PARAS2":"data","VALUE2":"fire的data"},
{template:0,"$tag":11,"METHOD":"off","PARAS1":"name","VALUE1":"name1"}

];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v2 = m0.VALUE2;
			var ani0 = mm("do_Animation");
			ani0.fillAfter = true;
			ani0.alpha({data:{
							 "delay":"0",
							 "duration":"4000",
							 "curve":"EaseInOut",
							 "repeatCount":"-1",
							 "autoReverse":"true",
							 "alphaFrom":"0.1",
							 "alphaTo":"0.5"
					}, id:m0v2});
			btn1.animate({animation:ani0}, function(data, e){});
			l1.animate({animation:ani0}, function(data, e){});
			tb1.animate({animation:ani0}, function(data, e){});
			web1.animate({animation:ani0}, function(data, e){});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v2 = m1.VALUE2;
			var ani1 = mm("do_Animation");
			ani1.fillAfter = false;
			ani1.alpha({data:{
							 "delay":"2000",
							 "duration":"2000",
							 "curve":"Linear",
							 "repeatCount":"2",
							 "autoReverse":"false",
							 "alphaFrom":"0.5",
							 "alphaTo":"0.9"
					}, id:m1v2});
			btn1.animate({animation:ani1}, function(data, e){
				nf.alert("dd")
			});
			l1.animate({animation:ani1}, function(data, e){});
			tb1.animate({animation:ani1}, function(data, e){});
			web1.animate({animation:ani1}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v2 = m2.VALUE2;
			var ani2 = mm("do_Animation");
			ani2.fillAfter = true;
			ani2.transfer({data:{
							 "delay":"0",
							 "duration":"4000",
							 "formX":"100",
							 "formY":"100",
							 "toX":"200",
							 "toY":"200"
					}, id:m2v2});
			btn1.animate({animation:ani2}, function(data, e){
				nf.alert("dd")
			});
			l1.animate({animation:ani2}, function(data, e){});
			tb1.animate({animation:ani2}, function(data, e){});
			web1.animate({animation:ani2}, function(data, e){});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v2 = m3.VALUE2;
			var ani3 = mm("do_Animation");
			ani3.fillAfter = false;
			ani3.transfer({data:{
							 "delay":"2000",
							 "duration":"2000",
							 "formX":"0",
							 "formY":"0",
							 "toX":"200",
							 "toY":"200"
					}, id:m3v2});
			btn1.animate({animation:ani3}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani3}, function(data, e){});
			tb1.animate({animation:ani3}, function(data, e){});
			web1.animate({animation:ani3}, function(data, e){});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v2 = m4.VALUE2;
			var ani4 = mm("do_Animation");
			ani4.fillAfter = true;
			ani4.scale({data:{
						"delay":"0",
						"duration"  :"3000",
						"autoReverse":"TRUE",
						"scaleFromX":"0.5",
						"scaleFromY":"0.5",
						"scaleToX":"1.5",
						"scaleToY":"1.5"
					}, id:m4v2});
			btn1.animate({animation:ani4}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani4}, function(data, e){});
			tb1.animate({animation:ani4}, function(data, e){});
			web1.animate({animation:ani4}, function(data, e){});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v2 = m5.VALUE2;
			var ani5 = mm("do_Animation");
			ani5.fillAfter = false;
			ani5.scale({data:{
						"delay":"3000",
						"duration"  :"4000",
						"autoReverse":"false",
						"scaleFromX":"0.2",
						"scaleFromY":"0.2",
						"scaleToX":"1.8",
						"scaleToY":"1.8"
					}, id:m5v2});
			btn1.animate({animation:ani5}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani5}, function(data, e){});
			tb1.animate({animation:ani5}, function(data, e){});
			web1.animate({animation:ani5}, function(data, e){});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v2 = m6.VALUE2;
			var ani6 = mm("do_Animation");
			ani6.fillAfter = true;
			ani6.rotate({data:{
						"duration"  :"2000",
						"fromDegree":"0",
						"toDegree"  :"90"
					}, id:m6v2});
			btn1.animate({animation:ani6}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani6}, function(data, e){});
			tb1.animate({animation:ani6}, function(data, e){});
			web1.animate({animation:ani6}, function(data, e){});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v2 = m7.VALUE2;
			var ani7 = mm("do_Animation");
			ani7.fillAfter = false;
			ani7.rotate({data:{
						"duration"  :"0",
						"fromDegree":"0",
						"toDegree"  :"270"
					}, id:m7v2});
			btn1.animate({animation:ani7}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani7}, function(data, e){});
			tb1.animate({animation:ani7}, function(data, e){});
			web1.animate({animation:ani7}, function(data, e){});
			break;
		case 8:
			var ani8 = mm("do_Animation");
			ani8.fillAfter = false;
			ani8.rotate({data:{
						"duration"  :"3000",
						"fromDegree":"0",
						"toDegree"  :"270"
					}, id:"id11"});
			ani8.scale({data:{
//						"delay":"3000",
						"duration"  :"3000",
						"autoReverse":"false",
						"scaleFromX":"0.2",
						"scaleFromY":"0.2",
						"scaleToX":"1.8",
						"scaleToY":"1.8"
					}, id:"id22"});
			ani8.transfer({data:{
//							 "delay":"7000",
							 "duration":"3000",
							 "formX":"0",
							 "formY":"0",
							 "toX":"200",
							 "toY":"200"
					}, id:"id33"});
			btn1.animate({animation:ani8}, function(data, e){nf.alert("dd")});
			l1.animate({animation:ani8}, function(data, e){});
			tb1.animate({animation:ani8}, function(data, e){});
			web1.animate({animation:ani8}, function(data, e){});
			break;
		case 9:
//			var m14 = listdata.getOne(14);
//			var m14v1 = m14.VALUE1;
//			var m14v2 = m14.VALUE2;
//			var m14v3 = m14.VALUE3;
			anitest.on({name:"name1", data:"ab123", delay:-1}, function(data, e){
				nf.toast("订阅name1消息");
				nf.toast(data);
		});
			break;
		case 10:
//			var m15 = listdata.getOne(15);
//			var m15v1 = m15.VALUE1;
//			var m15v2 = m15.VALUE2;
			anitest.fire({name:"name1", data:"123ab"});
			
			break;
		case 11:
//			var m16 = listdata.getOne(16);
//			var m16v1 = m15.VALUE1;
			anitest.off({name:"name1"});
			nf.toast("取消订阅name1消息");
			break;
	}
});
