var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"openPage","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			app.openPage("source://view/CORE/do_Page/page2.ui");
			break;
	}
});


page.on("back",function(data, e){
	nf.alert("back event is fired");
});
page.on("menu",function(data, e){
	nf.alert("menu event is fired");
});
page.on("result",function(data, e){
	deviceone.print("result event is fired");
	//nf.alert(data);
});
page.on("pause",function(data, e){
	deviceone.print("pause event is fired");
});
page.on("volumeUp",function(data, e){
	deviceone.print("volumeUp event is fired");
});
page.on("volumeDown",function(data, e){
	deviceone.print("volumeDown event is fired");
});
page.on("loaded",function(data, e){
	deviceone.print("loaded event is fired");
});
page.on("resume",function(data, e){
	deviceone.print("resume event is fired");
	//deviceone.print("")
});