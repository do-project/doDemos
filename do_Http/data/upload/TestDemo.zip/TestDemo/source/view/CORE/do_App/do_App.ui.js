var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"page_uncurl"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var ddd ;

var data0 =[
	{template:0,"$tag":0,"METHOD":"getAppID","PARAS1":"","VALUE1":""},
	{template:3,"$tag":1,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_l2r","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":2,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_r2l","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":3,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_b2t","PARAS4":"keyboardMode","VALUE4":"hidden"},
	{template:3,"$tag":4,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_t2b","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":5,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"push_l2r","PARAS4":"keyboardMode","VALUE4":"hidden"},
	{template:3,"$tag":6,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":ddd,"PARAS3":"animationType","VALUE3":"push_r2l","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":7,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"push_b2t","PARAS4":"keyboardMode","VALUE4":"hidden"},
	{template:3,"$tag":8,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"push_t2b","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":9,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"fade","PARAS4":"keyboardMode","VALUE4":"default"},
	{template:3,"$tag":10,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"page_curl","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":11,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"page_uncurl","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":12,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"cube","PARAS4":"keyboardMode","VALUE4":"default"},
	{template:4,"$tag":13,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new2.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"cube","PARAS4":"keyboardMode","VALUE4":"default","PARAS5":"scriptType","VALUE5":"lua"},
	{template:2,"$tag":14,"METHOD":"on","PARAS1":"name","VALUE1":"name1","PARAS2":"data","VALUE2":"abc123","PARAS3":"delay","VALUE3":"-1"},
	{template:1,"$tag":15,"METHOD":"fire","PARAS1":"name","VALUE1":"name1","PARAS2":"data","VALUE2":"fire的data"},
	{template:0,"$tag":16,"METHOD":"off","PARAS1":"name","VALUE1":"name1"},
	{template:2,"$tag":17,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/UIFile.ui","PARAS2":"statusBarState","VALUE2":"show","PARAS3":"statusBarFgColor","VALUE3":"white"},
	{template:2,"$tag":18,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/UIFile.ui","PARAS2":"statusBarState","VALUE2":"hide","PARAS3":"statusBarFgColor","VALUE3":"white"},
	{template:2,"$tag":19,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/UIFile.ui","PARAS2":"statusBarState","VALUE2":"transparent","PARAS3":"statusBarFgColor","VALUE3":"black"},
	{template:3,"$tag":20,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_l2r_1","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:3,"$tag":21,"METHOD":"openPage","PARAS1":"source","VALUE1":"source://view/CORE/do_App/new.ui","PARAS2":"data","VALUE2":"123abc你好啊！@#￥","PARAS3":"animationType","VALUE3":"slide_r2l_1","PARAS4":"keyboardMode","VALUE4":"visible"},
	{template:2,"$tag":22,"METHOD":"update","PARAS1":"source","VALUE1":["data://updateTest/update.ui","data://updateTest/update.ui.js"],"PARAS2":"target","VALUE2":"source://view/OTHERS/update"},
	
	
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var a = app.getAppID({});
			nf.alert(a);
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			var m1v3 = m1.VALUE3;
			var m1v4 = m1.VALUE4;
			app.openPage({source:m1v1, data:m1v2, animationType:m1v3, keyboardMode:m1v4}, function(data, e){});
			break;	
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
			var m2v3 = m2.VALUE3;
			var m2v4 = m2.VALUE4;
			app.openPage({source:m2v1, data:m2v2, animationType:m2v3, keyboardMode:m2v4}, function(data, e){});
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			var m3v3 = m3.VALUE3;
			var m3v4 = m3.VALUE4;
			app.openPage({source:m3v1, data:m3v2, animationType:m3v3, keyboardMode:m3v4}, function(data, e){
			
			 });
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var m4v2 = m4.VALUE2;
			var m4v3 = m4.VALUE3;
			var m4v4 = m4.VALUE4;
			app.openPage({source:m4v1, data:m4v2, animationType:m4v3, keyboardMode:m4v4}, function(data, e){
			
			 });
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var m5v2 = m5.VALUE2;
			var m5v3 = m5.VALUE3;
			var m5v4 = m5.VALUE4;
			app.openPage({source:m5v1, data:m5v2, animationType:m5v3, keyboardMode:m5v4}, function(data, e){
			
			 });
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			var m6v3 = m6.VALUE3;
			var m6v4 = m6.VALUE4;
			app.openPage({source:m6v1, data:m6v2, animationType:m6v3, keyboardMode:m6v4}, function(data, e){
			
			 });
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			var m7v3 = m7.VALUE3;
			var m7v4 = m7.VALUE4;
			app.openPage({source:m7v1, data:m7v2, animationType:m7v3, keyboardMode:m7v4}, function(data, e){
			
			 });
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			var m8v2 = m8.VALUE2;
			var m8v3 = m8.VALUE3;
			var m8v4 = m8.VALUE4;
			app.openPage({source:m8v1, data:m8v2, animationType:m8v3, keyboardMode:m8v4}, function(data, e){
			
			 });
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			var m9v3 = m9.VALUE3;
			var m9v4 = m9.VALUE4;
			app.openPage({source:m9v1, data:m9v2, animationType:m9v3, keyboardMode:m9v4}, function(data, e){
			
			 });
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			var m10v3 = m10.VALUE3;
			var m10v4 = m10.VALUE4;
			app.openPage({source:m10v1, data:m10v2, animationType:m10v3, keyboardMode:m10v4}, function(data, e){
			
			 });
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			var m11v3 = m11.VALUE3;
			var m11v4 = m11.VALUE4;
			app.openPage({source:m11v1, data:m11v2, animationType:m11v3, keyboardMode:m11v4}, function(data, e){
			
			 });
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var m12v2 = m12.VALUE2;
			var m12v3 = m12.VALUE3;
			var m12v4 = m12.VALUE4;
			app.openPage({source:m12v1, data:m12v2, animationType:m12v3, keyboardMode:m12v4}, function(data, e){

			 });
			break;
		case 13:
			var m13 = listdata.getOne(13);
			var m13v1 = m13.VALUE1;
			var m13v2 = m13.VALUE2;
			var m13v3 = m13.VALUE3;
			var m13v4 = m13.VALUE4;
			var m13v5 = m13.VALUE5;
			app.openPage({source:m13v1, data:m13v2, animationType:m13v3, keyboardMode:m13v4, scriptType:m13v5}, function(data, e){
			 	
			 });
			break;
		case 14:
//			var m14 = listdata.getOne(14);
//			var m14v1 = m14.VALUE1;
//			var m14v2 = m14.VALUE2;
//			var m14v3 = m14.VALUE3;
			app.on({name:"name1", data:"ab123", delay:-1}, function(data, e){
				nf.toast("订阅name1消息");
				nf.toast(data);
		});
			break;
		case 15:
//			var m15 = listdata.getOne(15);
//			var m15v1 = m15.VALUE1;
//			var m15v2 = m15.VALUE2;
			app.fire({name:"name1", data:"123ab"});
			
			break;
		case 16:
//			var m16 = listdata.getOne(16);
//			var m16v1 = m15.VALUE1;
			app.off({name:"name1"});
			nf.toast("取消订阅name1消息");
			break;
		case 17:
			var m17 = listdata.getOne(17);
			var m17v1 = m17.VALUE1;
			var m17v2 = m17.VALUE2;
			var m17v3 = m17.VALUE3;
			app.openPage({source:m17v1, statusBarState:m17v2, statusBarFgColor:m17v3}, function(data, e){
			 	
			 });
			break;
		case 18:
			var m18 = listdata.getOne(18);
			var m18v1 = m18.VALUE1;
			var m18v2 = m18.VALUE2;
			var m18v3 = m18.VALUE3;
			app.openPage({source:m18v1, statusBarState:m18v2, statusBarFgColor:m18v3}, function(data, e){
			 	
			 });
			break;
		case 19:
			var m19 = listdata.getOne(19);
			var m19v1 = m19.VALUE1;
			var m19v2 = m19.VALUE2;
			var m19v3 = m19.VALUE3;
			app.openPage({source:m19v1, statusBarState:m19v2, statusBarFgColor:m19v3}, function(data, e){
			 	
			 });
			break;
		case 20:
			var m20 = listdata.getOne(20);
			var m20v1 = m20.VALUE1;
			var m20v2 = m20.VALUE2;
			var m20v3 = m20.VALUE3;
			var m20v4 = m20.VALUE4;
			app.openPage({source:m20v1, data:m20v2, animationType:m20v3, keyboardMode:m20v4}, function(data, e){});
			break;	
		case 21:
			var m21 = listdata.getOne(21);
			var m21v1 = m21.VALUE1;
			var m21v2 = m21.VALUE2;
			var m21v3 = m21.VALUE3;
			var m21v4 = m21.VALUE4;
			app.openPage({source:m21v1, data:m21v2, animationType:m21v3, keyboardMode:m21v4}, function(data, e){});
			break;		
		case 22:
			var m22 = listdata.getOne(22);
			var m22v1 = m22.VALUE1;
			var m22v2 = m22.VALUE2;
			app.update(["data://updateTest"],"source://view/OTHERS/update");
			nf.alert("update done");
			break;	
	}
});

app.on("loaded",function(data, e){
	nf.alert("loaded event is fired");
});

page.on("result",function(data, e){
	nf.alert({text:data, title:"关闭上层传递下来的数据"}, function(data, e){});
});