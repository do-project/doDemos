var app = sm("do_App");

var do_button_1 = ui("do_button_1");
do_button_1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});
