var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"page_uncurl"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var zip1 = [
	"data://test123/test111.txt",
	"data://test123/files/TextFile.txt",
	"data://test123/0000.jpg"
];

var data0 =[
	{template:0,"$tag":0,"METHOD":"dirExist","PARAS1":"path","VALUE1":"data://test123"},
	{template:0,"$tag":1,"METHOD":"dirExist","PARAS1":"path","VALUE1":"data://test1234"},
	{template:0,"$tag":2,"METHOD":"fileExist","PARAS1":"path","VALUE1":"data://test123/test111.txt"},
	{template:0,"$tag":3,"METHOD":"fileExist","PARAS1":"path","VALUE1":"data://test123/test1112.txt"},
	{template:0,"$tag":4,"METHOD":"getFiles","PARAS1":"path","VALUE1":"data://test123"},
	{template:0,"$tag":5,"METHOD":"getDirs","PARAS1":"path","VALUE1":"data://test123"},
	{template:0,"$tag":6,"METHOD":"deleteDir","PARAS1":"path","VALUE1":"data://test123/files"},
	{template:0,"$tag":7,"METHOD":"deleteFile","PARAS1":"path","VALUE1":"data://test123/zzzip.zip"},
	{template:0,"$tag":8,"METHOD":"readFile","PARAS1":"path","VALUE1":"data://test123/test111.txt"},
	{template:1,"$tag":9,"METHOD":"writeFile","PARAS1":"path","VALUE1":"data://test123/new.txt","PARAS2":"data","VALUE2":"12345abcde你好啊@#￥……*（）"},
	{template:1,"$tag":10,"METHOD":"zip","PARAS1":"source","VALUE1":"data://test123/0000.jpg","PARAS2":"target","VALUE2":"data://test123/zip/1.zip"},
	{template:1,"$tag":11,"METHOD":"zipFiles","PARAS1":"source","VALUE1":zip1,"PARAS2":"target","VALUE2":"data://test123/zip/2.zip"},
	{template:1,"$tag":12,"METHOD":"unzip","PARAS1":"source","VALUE1":"data://test123/zip/1.zip","PARAS2":"target","VALUE2":"data://test123/unzip"},
	{template:1,"$tag":13,"METHOD":"unzip","PARAS1":"source","VALUE1":"data://test123/zip/2.zip","PARAS2":"target","VALUE2":"data://test123/unzip"},
	{template:1,"$tag":14,"METHOD":"copy","PARAS1":"source","VALUE1":"data://test123/zip/2.zip","PARAS2":"target","VALUE2":"data://test123/copy"},
	{template:1,"$tag":15,"METHOD":"copy","PARAS1":"source","VALUE1":zip1,"PARAS2":"target","VALUE2":"data://test123/copy"},
	{template:0,"$tag":16,"METHOD":"security"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			var a = storage.dirExist({path:m0v1});
			var b = typeof a;
				nf.alert({text:a, title:"目录是否存在"}, function(data, e){});
				nf.alert({text:b, title:"返回值类型"}, function(data, e){});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var c = storage.dirExist({path:m1v1});
			var d = typeof c;
				nf.alert({text:c, title:"目录是否存在"}, function(data, e){});
				nf.alert({text:d, title:"返回值类型"}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var e = storage.fileExist({path:m2v1});
			var f = typeof e;
				nf.alert({text:e, title:"文件是否存在"}, function(data, e){});
				nf.alert({text:f, title:"返回值类型"}, function(data, e){});
				
			break;
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var h = storage.fileExist({path:m3v1});
			var i = typeof h;
				nf.alert({text:h, title:"文件是否存在"}, function(data, e){});
				nf.alert({text:i, title:"返回值类型"}, function(data, e){});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			storage.getFiles({path:m4v1}, function(data, e){
				var j = typeof data;
				nf.alert({text:data, title:"获取文件列表"}, function(data, e){});
				nf.alert({text:j, title:"返回值类型"}, function(data, e){});
			});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			storage.getDirs({path:m5v1}, function(data, e){
				var k = typeof data;
				nf.alert({text:data, title:"获取目录列表"}, function(data, e){});
				nf.alert({text:k, title:"返回值类型"}, function(data, e){});
			});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			storage.deleteDir({path:m6v1}, function(data, e){
				var l = typeof data;
				nf.alert({text:data, title:"目录删除是否成功"}, function(data, e){});
				nf.alert({text:l, title:"返回值类型"}, function(data, e){});
			});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			storage.deleteFile({path:m7v1}, function(data, e){
				var m = typeof data;
				nf.alert({text:data, title:"文件删除是否成功"}, function(data, e){});
				nf.alert({text:m, title:"返回值类型"}, function(data, e){});
			});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			storage.readFile({path:m8v1}, function(data, e){
				var n = typeof data;
				nf.alert({text:data, title:"读文件"}, function(data, e){});
				nf.alert({text:n, title:"返回值类型"}, function(data, e){});
			});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			storage.writeFile({path:m9v1, data:m9v2}, function(data, e){
				var o = typeof data;
				nf.alert({text:data, title:"写文件是否成功"}, function(data, e){});
				nf.alert({text:o, title:"返回值类型"}, function(data, e){});
				storage.readFile({path:m9v1}, function(data, e){
					nf.alert({text:data, title:"读取写入的文件"}, function(data, e){});
				});
			});
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			storage.zip({source:m10v1, target:m10v2}, function(data, e){
				var p = typeof data;
				nf.alert({text:data, title:"压缩是否成功"}, function(data, e){});
				nf.alert({text:p, title:"返回值类型"}, function(data, e){});
				var ex = storage.fileExist({path:m10v2});
				nf.alert({text:ex, title:"判断压缩后的文件是否存在"}, function(data, e){});
			});
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			storage.zipFiles({source:m11v1, target:m11v2}, function(data, e){
				var q = typeof data;
				nf.alert({text:data, title:"压缩多个是否成功"}, function(data, e){});
				nf.alert({text:q, title:"返回值类型"}, function(data, e){});
				var ex2 = storage.fileExist({path:m11v2});
				nf.alert({text:ex2, title:"判断压缩后的文件是否存在"}, function(data, e){});
			});
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var m12v2 = m12.VALUE2;
			storage.unzip({source:m12v1, target:m12v2}, function(data, e){
				var r = typeof data;
//				nf.alert({text:data, title:"解压缩是否成功"}, function(data, e){});
//				nf.alert({text:r, title:"返回值类型"}, function(data, e){});
				deviceone.print(data);
				storage.getFiles({path:m12v2}, function(data, e){
					//nf.alert({text:data, title:"获取解压缩后的目录"}, function(data, e){});
					deviceone.print(data);
				});
			});
			break;
		case 13:
			var m13 = listdata.getOne(13);
			var m13v1 = m13.VALUE1;
			var m13v2 = m13.VALUE2;
			storage.unzip({source:m13v1, target:m13v2}, function(data, e){
				var s = typeof data;
				//nf.alert({text:data, title:"解压缩是否成功"}, function(data, e){});
				//nf.alert({text:s, title:"返回值类型"}, function(data, e){});
				deviceone.print(data);
				storage.getFiles({path:m13v2}, function(data, e){
					//nf.alert({text:data, title:"获取解压缩后的目录"}, function(data, e){});
					deviceone.print(data);
				});
			});
			break;
		case 14:
			var m14 = listdata.getOne(14);
			var m14v1 = m14.VALUE1;
			var m14v2 = m14.VALUE2;
			storage.copy({source:[m14v1], target:m14v2}, function(data, e){
				var t = typeof data;
				nf.alert({text:data, title:"拷贝文件是否成功"}, function(data, e){});
				nf.alert({text:t, title:"返回值类型"}, function(data, e){});
				//var b1 = storage.dirExist({path:m14v2});
				storage.getFiles({path:m14v2}, function(data, e){
					nf.alert({text:data, title:"读取拷贝后的目标文件内容"}, function(data, e){});
				});
				//nf.alert({text:b1, title:"判断拷贝后的目录是否存在"}, function(data, e){});
			});
			break;
		case 15:
			var m15 = listdata.getOne(15);
			var m15v1 = m15.VALUE1;
			var m15v2 = m15.VALUE2;
			storage.copy({source:m15v1, target:m15v2}, function(data, e){
				var u = typeof data;
				nf.alert({text:data, title:"拷贝文件是否成功"}, function(data, e){});
				nf.alert({text:u, title:"返回值类型"}, function(data, e){});
				//var b2 = storage.dirExist({path:m15v2});
				storage.getFiles({path:m15v2}, function(data, e){
					nf.alert({text:data, title:"读取拷贝后的目标文件内容"}, function(data, e){});
				});
				//nf.alert({text:b2, title:"判断拷贝后的目录是否存在"}, function(data, e){});
			});
			break;
		case 16:
			storage.writeFile("data://security/1.txt", "123abc@#$", function(data, e) {
				storage.readFile("data://security/1.txt", function(data, e) {
					nf.alert(data);
				})
			})
			break;
	}
});
