
var page = sm("do_Page");
var app  = sm("do_App");
var nf = sm("do_Notification");

page.on("back",function (data, e){
   app.closePage({"data":"page2传过来的data数据", "animationType":""}, function(data, e){});
});

page.on("loaded",function (data, e){
    var data =  page.getData();
    nf.alert({text:data, title:"page2"}, function(data, e){});
});

var do_imageview_1 = ui("do_imageview_1");
do_imageview_1.on("touch",function(data, e){
	app.closePage({"data":"page2传过来的data数据", "animationType":""}, function(data, e){});
});

var key = ui("key");
key.on("touch",function(data, e){
	page.hideKeyboard();
});

var do_button_1 = ui("do_button_1");
do_button_1.on("touch",function(data, e){
	page.remove({id:"label_1"});
});
