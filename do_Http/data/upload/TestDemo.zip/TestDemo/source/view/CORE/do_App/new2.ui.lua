local app = sm("do_App");
local page = sm("do_Page");

local img1 = ui("img1");

img1:on("touch",function(data, e, self)
	app:closePage({data="", animationType=""}, function(data, e, self)

  end);	
end);