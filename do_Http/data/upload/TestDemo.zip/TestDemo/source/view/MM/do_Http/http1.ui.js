var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});
var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
{"$tag":0,"METHOD":"method-GET"},
{"$tag":1,"METHOD":"method-POST"},
{"$tag":2,"METHOD":"method-PUT"},
{"$tag":3,"METHOD":"method-PATCH"},
{"$tag":4,"METHOD":"method-DELETE"}

];

listdata.addData(data0);
list1.refreshItems({});

var http = mm("do_Http");
http.timeout = "10000";

http.on("fail",function(){
	deviceone.print(JSON.stringify(data),"fail event");
})
http.on("progress",function(){
	deviceone.print(JSON.stringify(data),"progress event");
})
http.on("success",function(){
	deviceone.print(data,"progress event");
})

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			http.method = "GET";
			http.url = "http://developertest.deviceone.cn/test/GetHeader";
			http.request();
			break;
		case 1:
			
			break;
		case 2:
			http.method = "PUT";
			http.url = "http://developertest.deviceone.cn/test/TestHttpPut";
			http.request();
			break;
		case 3:
			http.method = "PATCH";
			http.url = "http://developertest.deviceone.cn/test/TestHttpPatch";
			http.request();
			break;
		case 4:
			http.method = "DELETE";
			http.url = "http://developertest.deviceone.cn/test/TestHttpDelete";
			http.request();
			break;
	}
});

