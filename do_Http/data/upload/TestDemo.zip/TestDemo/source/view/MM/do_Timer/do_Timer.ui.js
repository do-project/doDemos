var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var timer = mm("do_Timer");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
	{template:0,"$tag":0,"METHOD":"start1","PARAS1":"备注","VALUE1":"delay3秒，interval2秒"},
	{template:0,"$tag":1,"METHOD":"start2","PARAS1":"备注","VALUE1":"delay0秒，interval1秒"},
	{template:0,"$tag":2,"METHOD":"stop","PARAS1":"","VALUE1":""},
	{template:0,"$tag":3,"METHOD":"isStart","PARAS1":"","VALUE1":""}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			timer.delay = "3000";
			timer.interval = "2000";
			timer.start({});
			nf.alert("start timer");
			break;
		case 1:
			timer.delay = "0";
			timer.interval = "1000";
			timer.start({});
			nf.alert("start timer");
			break;
		case 2:
			timer.stop({});
			nf.alert("stop timer");
			break;	
		case 3:
			var vv = timer.isStart({});
			nf.alert({text:vv, title:"定时器是否启动状态"}, function(data, e){});
			break;	
	}
});

timer.on("tick",function(data, e){
	nf.toast({text:"timer"}, function(data, e){});
});