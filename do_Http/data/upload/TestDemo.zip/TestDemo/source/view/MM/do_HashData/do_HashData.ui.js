var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var hash = mm("do_HashData");
/***********************/
hash.on("dataRefreshed",function(data, e){
	nf.alert({text:"dataRefreshed event is fired", title:""}, function(data, e){});
});
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var d = {
	"k1":"111","k2":"222","k3":"333"
};

var d1 = {
		"k1":[111],"k2":[222],"k3":[333]
	};


var data0 =[
	{template:0,"$tag":0,"METHOD":"getCount","PARAS1":"","VALUE1":""},
	{template:1,"$tag":1,"METHOD":"addOne1","PARAS1":"key","VALUE1":"key1","PARAS2":"value","VALUE2":"abcde你好"},
	{template:1,"$tag":2,"METHOD":"addOne1","PARAS1":"key","VALUE1":"key2","PARAS2":"value","VALUE2":12345},
	{template:1,"$tag":3,"METHOD":"addOne1","PARAS1":"key","VALUE1":"key3","PARAS2":"value","VALUE2":false},
	{template:0,"$tag":4,"METHOD":"addData","PARAS1":"data","VALUE1":d},
	{template:0,"$tag":5,"METHOD":"getOne","PARAS1":"key","VALUE1":"key1"},
	{template:0,"$tag":6,"METHOD":"getData","PARAS1":"key","VALUE1":"k1,k2,k3"},
	{template:0,"$tag":7,"METHOD":"getAll","PARAS1":"key","VALUE1":""},
	{template:0,"$tag":8,"METHOD":"removeOne","PARAS1":"key","VALUE1":"key2"},
	{template:0,"$tag":9,"METHOD":"removeData","PARAS1":"key","VALUE1":"key1"},
	{template:0,"$tag":10,"METHOD":"removeAll","PARAS1":"","VALUE1":""},
	{template:0,"$tag":11,"METHOD":"dataRefreshed","PARAS1":"","VALUE1":""},
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var count = hash.getCount({});
			nf.alert({text:count, title:"元素个数"}, function(data, e){});
			var count1 = hash.getAll({});
			nf.alert({text:count1, title:"获取全部数据"}, function(data, e){});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var m1v2 = m1.VALUE2;
			hash.addOne("key1", [{"ccc": "ccccccccc"}]);
//			hash.addOne("key1", "abcde你好");
			nf.toast({text:"addone data is abcde你好"}, function(data, e){});
			var one1 = hash.getOne("key1");
			nf.alert({text:one1, title:"获取addone的value"}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var m2v2 = m2.VALUE2;
//			hash.addOne({key:m2v1, value:m2v2});
			hash.addOne("key1", {"bbb": "bbbbbbbb"});
			nf.toast({text:"addone data is 12345"}, function(data, e){});
			var one2 = hash.getOne("key1");
			nf.alert({text:one2, title:"获取addone的value"}, function(data, e){});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var m3v2 = m3.VALUE2;
			hash.addOne({key:m3v1, value:m3v2});
			nf.toast({text:"addone data is false"}, function(data, e){});
			//var one3 = hash.getOne({key:m3v1});
			var one3 = hash.getOne("c");
			nf.alert({text:one3, title:"获取addone的value"}, function(data, e){});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			hash.addData({data:m4v1});
			var count0 = hash.getCount({});
			nf.alert({text:count0, title:"元素个数"}, function(data, e){});
			var count2 = hash.getAll({});
			nf.alert({text:count2, title:"获取全部数据"}, function(data, e){});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var one11 = hash.getOne({key:m5v1});
			nf.alert({text:one11, title:"获取key1的数据abcde你好"}, function(data, e){});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var one6 = hash.getData({keys:"key1"});
			nf.alert({text:one6, title:"获取key1的数据"}, function(data, e){});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var one7 = hash.getAll({});
			nf.alert({text:one7, title:"获取全部数据"}, function(data, e){});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			hash.removeOne({key:m8v1});
			var one8 = hash.getData({keys:m8v1});
			nf.alert({text:one8, title:"获取删除的key2的值"}, function(data, e){});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			hash.removeData({keys:"key1"});
			var one81 = hash.getData({keys:"key1"});
			nf.alert({text:one81, title:"获取删除的key1的值"}, function(data, e){});
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			hash.removeAll({});
			var one01 = hash.getCount({});
			nf.alert({text:one01, title:"获取删除全部数据后的元素个数"}, function(data, e){});
			break;
		case 11:
				var hh = mm("do_HashData");
				var dd = {"item1_text":"ttttttt"};
				hh.addData(dd);
		
				hash.bindData({data:hh, mapping:{"url":"item1_text"}});
				hash.refreshData({});
			break;
	}
});
