var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"slide_l2r"}, function(data, e){});
});
var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data0 =[
{"$tag":0,"METHOD":"GET"},
{"$tag":1,"METHOD":"POST"},
{"$tag":2,"METHOD":"PUT"},
{"$tag":3,"METHOD":"PATCH"},
{"$tag":4,"METHOD":"DELETE"},
{"$tag":5,"METHOD":"download"},
{"$tag":6,"METHOD":"upload"},
{"$tag":7,"METHOD":"setRequestHeader"},
{"$tag":8,"METHOD":"getResponseHeader"},
{"$tag":9,"METHOD":"upload_PUT"}
];

listdata.addData(data0);
list1.refreshItems({});

var http = mm("do_Http");
http.timeout = "10000";

http.on("fail",function(data,e){
	deviceone.print(JSON.stringify(data),"fail event");
})
http.on("progress",function(data,e){
	deviceone.print(JSON.stringify(data),"progress event");
})
http.on("success",function(data,e){
	deviceone.print(JSON.stringify(data),"success event");
})

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			http.url = "http://developer.deviceone.cn/test/getheader";
			http.method = "get";
			http.setRequestHeader("CHILD1", "child111");
			http.setRequestHeader("CHILD2", "child222");
			var header1 = http.getResponseHeader("CHILD2");
			http.request();
			deviceone.print(header1,"getResponseHeader-CHILD2");
			break;
		case 1:
			http.method = "POST";
			http.url = "http://developertest.deviceone.cn/test/GetHeader";
			http.request();
			break;
		case 2:
			http.method = "PUT";
			http.url = "http://developertest.deviceone.cn/test/TestHttpPut";
			http.body = "abcde";
			http.request();
			break;
		case 3:
			http.method = "PATCH";
			http.url = "http://developertest.deviceone.cn/test/TestHttpPatch";
			http.body = {dddd:"deviceone"};
			http.request();
			break;
		case 4:
			http.method = "DELETE";
			http.url = "http://developertest.deviceone.cn/test/TestHttpDelete";
			http.body = "delete";
			http.request();
			break;
		case 5:
			http.url = "http://ds2.deviceone.net/Files/install/20151103/342c733d-c491-4e34-a25c-c7fd8c47c126.apk";
			http.download("data://download/test.zip");
			break;
		case 6:
			http.url = "http://developertest.deviceone.cn/test/upload";
			http.method = "POST";
			http.contentType = "multipart/form-data";
			http.upload({path:"data://1.jpg", name:"file"});
			break;
		case 7:
			http.url = "http://developertest.deviceone.cn/test/getheader";
			http.method = "get";
			http.setRequestHeader("CHILD1", "child111");
			http.setRequestHeader("CHILD2", "child222");
			http.request();
			break;
		case 8:
			http.url = "http://developertest.deviceone.cn/test/getheader";
			http.method = "get";
			http.setRequestHeader("CHILD3", "12222");
			http.setRequestHeader("CHILD3", "33333");
			http.request();
			var hh = http.getResponseHeader("host");
			nf.alert(hh,"host");
			break;
		case 9:
			http.url = "http://developertest.deviceone.cn/test/UploadPut";
			http.method = "PUT";
			http.contentType = "multipart/form-data";
			http.upload({path:"data://00.jpg", name:"file"});
			break;
	}
});

