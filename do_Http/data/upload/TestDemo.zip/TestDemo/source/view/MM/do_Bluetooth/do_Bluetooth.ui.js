var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

var blue = mm("do_Bluetooth");
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});
/***********************/

blue.on("progress",function(data,e){
	deviceone.print(JSON.stringify(data),"progress event");
})
blue.on("receive",function(data,e){
	deviceone.print(JSON.stringify(data),"receive event");
})

var service0 = { "B0EB4C14-0544-440F-81C7-3207F88F6A7B":["335683ED-CA41-472A-926D-87D62828E421","9DBA88C5-9E08-4557-983D-80ADFAB92602"]};
var serviceTZC = {
		"96F22BCA-F08C-43F9-BF7D-EEBC579C94D2":
		[
		 "21C7DE8E-B0D0-4A41-9B22-78221277E2AA",
		 "00E12465-2E2F-4C6B-9FD2-E84A8A088C68",
		 "A109B433-96A0-463A-A070-542C5A15E177",
		 "6EAEC220-5EB0-4181-8858-D40E1EE072F6"
		 ]	
}

ui("openPeripheral").on("touch",function(){
	blue.openPeripheral(service0, function(data, e) {
		nf.alert(data,"打开外围设备是否成功")
	})
})

ui("openCentral").on("touch",function(){
	blue.openCentral(function(data, e) {
		nf.alert(data,"打开中心设备是否成功")
	})
})

ui("connect").on("touch",function(){
	blue.connect(service0, function(data, e) {
		nf.alert(data, "连接外围设备是否成功");
	})
})

ui("connectTZC").on("touch",function(){
	blue.connect(serviceTZC, function(data, e) {
		nf.alert(data, "连接体脂称是否成功");
	})
})

ui("setReceive1").on("touch",function(){
	blue.setReceive("flag", "#", "UTF-8");
	nf.alert("设置以#结尾的UTF-8");
})

ui("send1").on("touch",function(){
	blue.send("UTF-8", "123ab#cd789", "335683ED-CA41-472A-926D-87D62828E421", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("setReceive2").on("touch",function(){
	blue.setReceive("flag", "@", "GBK");
	nf.alert("设置以@结尾的GBK");
})

ui("send2").on("touch",function(){
	blue.send("GBK", "123ab#cd789abd345@eeef89", "9DBA88C5-9E08-4557-983D-80ADFAB92602", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})


ui("setReceive3").on("touch",function(){
	blue.setReceive("length", 2, "HEX");
	nf.alert("设置长度为2的HEX");
})

ui("send3").on("touch",function(){
	blue.send("HEX", "4f5da2", "9DBA88C5-9E08-4557-983D-80ADFAB92602", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("setReceive4").on("touch",function(){
	blue.setReceive("length", 5, "data://receive/receive.zip");
	nf.alert("设置长度为5的data目录文件");
})

ui("send4").on("touch",function(){
	blue.send("file", "data://7.jpg", "9DBA88C5-9E08-4557-983D-80ADFAB92602", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("close").on("touch",function(){
	blue.close();
})



