var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var sql = mm("do_SQLite");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var sql0 = "delete from user";
var sql1 = "insert into user (id,name,password) values ('a1','mike','123')";
var sql2 = "select * from user";
var sql3 = "select * from user order by id desc";
var sql4 = "insert into user (id,name,password) values ('b2','jake','123')";

var data0 =[
	{template:0,"$tag":0,"METHOD":"open","PARAS1":"path","VALUE1":"data://dbtest1.db"},
	{template:0,"$tag":1,"METHOD":"close","PARAS1":"","VALUE1":""},
	{template:0,"$tag":2,"METHOD":"executeSync","PARAS1":"sql","VALUE1":sql1},
	{template:0,"$tag":3,"METHOD":"execute","PARAS1":"sql","VALUE1":sql4},
	{template:0,"$tag":4,"METHOD":"query","PARAS1":"sql","VALUE1":sql3},
	{template:0,"$tag":5,"METHOD":"query","PARAS1":"sql","VALUE1":"查询空"},
	{template:0,"$tag":6,"METHOD":"事务测试"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var m0 = listdata.getOne(0);
			var m0v1 = m0.VALUE1;
			sql.open({path:m0v1});
			nf.alert({text:"打开数据库", title:""}, function(data, e){});
			break;
		case 1:
			sql.close({});
			nf.alert({text:"关闭数据库", title:""}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var a = sql.executeSync({sql:m2v1});
			nf.alert({text:a, title:"执行方法是否成功"}, function(data, e){});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			sql.execute({sql:m3v1}, function(data, e){
				sql.query({sql:sql2}, function(data, e){
					nf.alert({text:data, title:"查询结果"}, function(data, e){});
				});
				nf.alert({text:data, title:"执行方法是否成功"}, function(data, e){});
			});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			sql.query({sql:m4v1}, function(data, e){
				nf.alert({text:data, title:"查询结果"}, function(data, e){});
			});
			break;
		case 5:
			sql.query({sql:""}, function(data, e){
				nf.alert({text:data, title:"查询结果"}, function(data, e){});
			});
			break;
		case 6:
			sql.query({sql:""}, function(data, e){
				nf.alert({text:data, title:"查询结果"}, function(data, e){});
			});
			break;
	}
});

