var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});
/***********************/

var animator1 = mm("do_Animator");
var animator2 = mm("do_Animator");
//var animator3 = mm("do_Animator");


 var a1 = {"x":"0","y":"0","width":"100","height":"80","bgColor":"#FF6A6A"}
 var a2 = {"x":"10","y":"10","width":"110","height":"90","bgColor":"#97FFFF"}
 var a3 = {"x":"20","y":"20","width":"120","height":"100","bgColor":"#9400D3"}
 var a4 = {"x":"30","y":"30","width":"130","height":"110","bgColor":"#919191"}
 var a5 = {"x":"40","y":"40","width":"140","height":"120","bgColor":"#8E388E"}
 var a6 = {"x":"50","y":"50","width":"150","height":"130","bgColor":"#87CEFA"}
 var a7 = {"x":"60","y":"60","width":"160","height":"140","bgColor":"#76EE00"}
 var a8 = {"x":"70","y":"70","width":"170","height":"150","bgColor":"#63B8FF"}
 var a9 = {"x":"80","y":"80","width":"180","height":"160","bgColor":"#B03060"}
 var a10 = {"x":"90","y":"90","width":"190","height":"170","bgColor":"#B03064"}
 var a11 = {"x":"150","y":"190","width":"190","height":"170","bgColor":"#B03064"}
         
 var b1 = {"width":"100","height":"80"}
 var b2 = {"width":"100","height":"80"}
 var b3 = {"width":"100","height":"80"}
 var b4 = {"width":"200","height":"160"}
 var b5 = {"width":"300","height":"240"}
 var b6 = {"width":"200","height":"100","bgColor":"#FFFF00FF"}
 var b7 = {"width":"200","height":"100","bgColor":"#FFD700FF"}
 var b8 = {"width":"300","height":"110","bgColor":"#FFC125FF"}
 var b9 = {"width":"300","height":"120","bgColor":"#FFB90FFF"}
 var b10 = {"x":"158","y":"149","width":"265","height":"301","bgColor":"8080FFFF"}

animator1.append(500, a1, "EaseInOut");
animator1.append(1500, a2, "EaseInOut");
animator1.append(1000, a3, "EaseInOut");
animator1.append(500, a4, "EaseInOut");
animator1.append(700, a5, "EaseInOut");
animator1.append(1000, a6, "EaseInOut");
animator1.append(900, a7, "EaseInOut");
animator1.append(200, a8, "EaseInOut");
animator1.append(100, a9, "EaseInOut");
animator1.append(2000, a10, "EaseInOut");
animator1.append(2000, a11, "EaseIn");


animator2.append(1000, b1, "EaseIn");
animator2.append(1000, b2, "EaseIn");
animator2.append(1000, b3, "EaseIn");
animator2.append(1000, b4, "EaseIn");
animator2.append(1000, b5, "EaseIn");
animator2.append(1000, a3, "EaseInOut");
animator2.append(500, a4, "EaseInOut");
animator2.append(700, a5, "EaseInOut");
animator2.append(1000, a6, "EaseInOut");
animator2.append(900, a7, "EaseInOut");
animator2.append(1000, b6, "EaseIn");
animator2.append(1000, b7, "EaseIn");
animator2.append(1000, b8, "EaseIn");
animator2.append(1000, b9, "EaseIn");
animator2.append(1000, b10, "EaseIn");

var btn1 = ui("do_Button_1");
var img1 = ui("do_ImageView_1");
var alayout1 = ui("do_ALayout_2");

btn1.on("touch",function(){
	btn1.animate(animator1, function(data, e) {
		deviceone.print("animator2 over");
	})
})
img1.on("touch",function(){
	img1.animate(animator2, function(data, e) {
		deviceone.print("animator1 over");
	})
})

	img1.animate(animator2, function(data, e) {
		deviceone.print("animator2 over");
	})
	alayout1.animate(animator2, function(data, e) {
		deviceone.print("animator2 over");
	})
