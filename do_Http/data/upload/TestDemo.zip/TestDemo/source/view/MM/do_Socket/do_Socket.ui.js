var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");

var socket = mm("do_Socket");
/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});
/***********************/
var cip = ui("ip")
var cport = ui("port")
var receive = ui("do_TextBox_1");

ui("connect").on("touch",function(){
	var ip1 = cip.text.trim();
	var port1 = cport.text.trim();
	socket.connect(ip1, port1, function(data, e) {
		nf.alert(data);
	})
})

socket.on("receive",function(data,e){
//	nf.alert(data,"receive event");
	deviceone.print(data,"receive event");
	receive.text = data;
	var type = typeof(data);
	deviceone.print(type,"receive事件返回值类型");
})
var content = receive.text;
//deviceone.print(,)

ui("send1").on("touch",function(){
	socket.send("UTF-8", "10", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})


ui("send2").on("touch",function(){
	socket.send("GBK", content, function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("send3").on("touch",function(){
	socket.send("HEX", content, function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("send4").on("touch",function(){
	socket.send("file", "data://test123/test111.txt", function(data, e) {
		nf.alert(data,"发送是否成功");
	})
})

ui("close").on("touch",function(){
	socket.close();
	nf.alert("close socket");
})



