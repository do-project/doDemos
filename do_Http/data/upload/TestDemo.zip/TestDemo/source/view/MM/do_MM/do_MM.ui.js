var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var timer = mm("do_Timer");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var animation1 = mm("do_Animation");
animation1.load("data://animation.json",function(){
	var btnanimation1 = ui("animation1");
	btnanimation1.on("touch",function(){
			btnanimation1.animate(animation1, function(data, e) {
				nf.alert("动画运行结束");
			})
	})
});

var animation2 = mm("do_Animation");
animation2.loadSync("source://view/MM/do_MM/animation.json")
var btnanimation2 = ui("animation2");
btnanimation2.on("touch",function(){
	btnanimation2.animate(animation2, function(data, e) {
		nf.alert("sync动画运行结束");
	})
})
/***********************/
var listdata1 = mm("do_ListData");
listdata1.load("source://view/MM/do_MM/listdata.json", function(data, e) {
	deviceone.print(data,"json的回调返回值");
	var ldbtn = ui("listdata1");
	ldbtn.on("touch",function(){
		deviceone.print("button touch");
		var count1 = listdata1.getCount()
		deviceone.print(count1,"获取listdata条数1");
	})
})
var listdata2 = mm("do_ListData");
listdata2.load("source://view/MM/do_MM/listdata.json");
var ldbtn2 = ui("listdata2");
ldbtn2.on("touch",function(){
	var count2 = listdata2.getCount()
	deviceone.print(count2,"获取listdata条数2");
})

/***********************/
var anima1 = mm("do_Animator");

var animabtn1 = ui("animator1");
animabtn1.on("touch",function(){
	anima1.load("source://view/MM/do_MM/animator.json", function(data, e) {
		animabtn1.animate(anima1, function(data, e) {
			deviceone.print("动画运行结束");
		})
	})
})

var anima2 = mm("do_Animator");
var animabtn2 = ui("animator2");
animabtn2.on("touch",function(){
	anima2.loadSync("source://view/MM/do_MM/animator.json");
	animabtn2.animate(anima2, function(data, e) {
		deviceone.print("sync动画运行结束");
	})
})
/***********************/
var hash1 = mm("do_HashData");
hash1.load("source://view/MM/do_MM/hash.json", function(data, e) {
	deviceone.print(data,"json的回调返回值");
	var hashdata1btn = ui("hashdata1");
	hashdata1btn.on("touch",function(){
		var count3 = listdata1.getCount()
		deviceone.print(count3,"获取hashdata条数1");
	})
})

var hash12 = mm("do_HashData");
hash12.loadSync("source://view/MM/do_MM/hash.json");
var hashdata2btn = ui("hashdata2");
hashdata2btn.on("touch",function(){
	var count4 = listdata2.getCount()
	deviceone.print(count4,"获取hashdata条数2");
})