var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var listd = mm("do_ListData");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:"push_b2t"}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var list1 = ui("list1");
var listdata = mm("do_ListData");
list1.bindItems(listdata);

var data1 = [
	"aa",
	"bb",
	"cc",
	"dd",
	"ee",
	"ff",
	"gg"
];
var data2 = [
	"11",
	"22",
	"33",
	"44",
	"55",
	"66",
	"77"
];
var data3 = [
	"你",
	"好",
	"啊",
	"哈",
	"嘿"
];

var data0 =[
	{template:0,"$tag":0,"METHOD":"getCount","PARAS1":"","VALUE1":""},
	{template:0,"$tag":1,"METHOD":"getData1","PARAS1":"index","VALUE1":"-1"},
	{template:0,"$tag":2,"METHOD":"getData2","PARAS1":"index","VALUE1":"1,3,5"},
	{template:0,"$tag":3,"METHOD":"getData3","PARAS1":"index","VALUE1":"100"},
	{template:0,"$tag":4,"METHOD":"getOne1","PARAS1":"index","VALUE1":"-2"},
	{template:0,"$tag":5,"METHOD":"getOne2","PARAS1":"index","VALUE1":"100"},
	{template:1,"$tag":6,"METHOD":"getRange","PARAS1":"fromIndex","VALUE1":"0","PARAS2":"toIndex","VALUE2":""},
	{template:1,"$tag":7,"METHOD":"getRange","PARAS1":"fromIndex","VALUE1":"1","PARAS2":"toIndex","VALUE2":"3"},
	{template:1,"$tag":8,"METHOD":"addData","PARAS1":"data","VALUE1":data1,"PARAS2":"index","VALUE2":"0"},
	{template:1,"$tag":9,"METHOD":"addData","PARAS1":"data","VALUE1":data2,"PARAS2":"index","VALUE2":"3"},
	{template:1,"$tag":10,"METHOD":"addData","PARAS1":"data","VALUE1":data3,"PARAS2":"index","VALUE2":"100"},
	{template:1,"$tag":11,"METHOD":"addOne","PARAS1":"data","VALUE1":"!@#$","PARAS2":"index","VALUE2":"0"},
	{template:1,"$tag":12,"METHOD":"addOne","PARAS1":"data","VALUE1":"+——）（","PARAS2":"index","VALUE2":"100"},
	{template:0,"$tag":13,"METHOD":"removeAll","PARAS1":"","VALUE1":""},
	{template:1,"$tag":14,"METHOD":"removeRange","PARAS1":"fromIndex","VALUE1":"1","PARAS2":"toIndex","VALUE2":"3"},
	{template:1,"$tag":15,"METHOD":"removeRange","PARAS1":"fromIndex","VALUE1":"0","PARAS2":"toIndex","VALUE2":"100"},
	{template:0,"$tag":16,"METHOD":"removeData","PARAS1":"indexs","VALUE1":"2,4,6"},
	{template:1,"$tag":17,"METHOD":"updateOne","PARAS1":"index","VALUE1":"0","PARAS2":"data","VALUE2":"new1"},
	{template:1,"$tag":18,"METHOD":"updateOne","PARAS1":"index","VALUE1":"100","PARAS2":"data","VALUE2":"new2"}
];

listdata.addData(data0);
list1.refreshItems({});

list1.on("touch",function(index){
	var all = listdata.getOne(index);
	var tag = all.$tag;
	switch (tag){
		case 0:
			var count = listd.getCount({});
			nf.alert({text:count, title:"元素个数"}, function(data, e){});
			var count2 = count-1;
			var count1 = listd.getRange({fromIndex:0, toIndex:count2});
			nf.alert({text:count1, title:"获取全部数据"}, function(data, e){});
			break;
		case 1:
			var m1 = listdata.getOne(1);
			var m1v1 = m1.VALUE1;
			var one1 = listd.getData({indexs:[-1]});
			nf.alert({text:one1, title:"获取最后一条数据"}, function(data, e){});
			break;
		case 2:
			var m2 = listdata.getOne(2);
			var m2v1 = m2.VALUE1;
			var one2 = listd.getData({indexs:[1,3,5]});
			nf.alert({text:one2, title:"获取index为1,3,5的数据"}, function(data, e){});
			break;	
		case 3:
			var m3 = listdata.getOne(3);
			var m3v1 = m3.VALUE1;
			var one3 = listd.getData({indexs:[m3v1]});
			nf.alert({text:one3, title:"获取越界数组下标的值，应该返回空"}, function(data, e){});
			break;
		case 4:
			var m4 = listdata.getOne(4);
			var m4v1 = m4.VALUE1;
			var count2 = listd.getOne({index:m4v1});
			nf.alert({text:count2, title:"获取下标为空时数据"}, function(data, e){});
			break;
		case 5:
			var m5 = listdata.getOne(5);
			var m5v1 = m5.VALUE1;
			var one11 = listd.getOne({index:m5v1});
			nf.alert({text:one11, title:"获取越界下标的数据"}, function(data, e){});
			break;
		case 6:
			var m6 = listdata.getOne(6);
			var m6v1 = m6.VALUE1;
			var m6v2 = m6.VALUE2;
			var one6 = listd.getRange({fromIndex:m6v1, toIndex:m6v2});
			nf.alert({text:one6, title:"获取从0到最后一条的数据"}, function(data, e){});
			break;
		case 7:
			var m7 = listdata.getOne(7);
			var m7v1 = m7.VALUE1;
			var m7v2 = m7.VALUE2;
			var one7 = listd.getRange({fromIndex:m7v1, toIndex:m7v2});
			nf.alert({text:one7, title:"获取从1到3共4条数据"}, function(data, e){});
			break;
		case 8:
			var m8 = listdata.getOne(8);
			var m8v1 = m8.VALUE1;
			var m8v2 = m8.VALUE2;
			listd.addData({data:m8v1, index:m8v2});
			var  a = listd.getCount({})-1;
			var one8 = listd.getRange({fromIndex:0, toIndex:a});
			nf.alert({text:one8, title:"数据插在最前，并获取全部数据"}, function(data, e){});
			break;
		case 9:
			var m9 = listdata.getOne(9);
			var m9v1 = m9.VALUE1;
			var m9v2 = m9.VALUE2;
			listd.addData({data:m9v1, index:m9v2});
			var  b = listd.getCount({})-1;
			var one9 = listd.getRange({fromIndex:0, toIndex:b});
			nf.alert({text:one9, title:"数据插在第四位，并获取全部数据"}, function(data, e){});
			break;
		case 10:
			var m10 = listdata.getOne(10);
			var m10v1 = m10.VALUE1;
			var m10v2 = m10.VALUE2;
			listd.addData({data:m10v1, index:m10v2});
			var  c = listd.getCount({})-1;
			var one10 = listd.getRange({fromIndex:0, toIndex:c});
			nf.alert({text:one10, title:"数组越界，数据插在最后，并获取全部数据"}, function(data, e){});
			break;
		case 11:
			var m11 = listdata.getOne(11);
			var m11v1 = m11.VALUE1;
			var m11v2 = m11.VALUE2;
			listd.addOne({data:m11v1, index:m11v2});
			var  d = listd.getCount({})-1;
			var one111 = listd.getRange({fromIndex:0, toIndex:d});
			nf.alert({text:one111, title:"数据插在第一个，并获取全部数据"}, function(data, e){});
			break;
		case 12:
			var m12 = listdata.getOne(12);
			var m12v1 = m12.VALUE1;
			var m12v2 = m12.VALUE2;
			listd.addOne({data:m12v1, index:m12v2});
			var  e = listd.getCount({})-1;
			var one12 = listd.getRange({fromIndex:0, toIndex:e});
			nf.alert({text:one12, title:"数组越界，数据插在最后，并获取全部数据"}, function(data, e){});
			break;
		case 13:
			listd.removeAll({});
			var f = listd.getCount({});
			nf.alert({text:f, title:"删除全部数据后获取元素个数"}, function(data, e){});
			break;
		case 14:
			var m14 = listdata.getOne(14);
			var m14v1 = m14.VALUE1;
			var m14v2 = m14.VALUE2;
			listd.removeRange({fromIndex:m14v1, toIndex:m14v2});
			var  c4 = listd.getCount({})-1;
			var one14 = listd.getRange({fromIndex:0, toIndex:c4});
			nf.alert({text:one14, title:"删除第2到4条数据并获取全部数据"}, function(data, e){});
			break;
		case 15:
			var m15 = listdata.getOne(15);
			var m15v1 = m15.VALUE1;
			var m15v2 = m15.VALUE2;
			listd.removeRange({fromIndex:m15v1, toIndex:m15v2});
			var  c15 = listd.getCount({});
			//var one15 = listd.getRange({fromIndex:0, toIndex:m15v2});
			nf.alert({text:c15, title:"数组越界toIndex到最后一条表示删除全部数据，获取元素个数"}, function(data, e){});
			break;
		case 16:
			listd.removeData({indexs:[2,4,6]});
			var  c16 = listd.getCount({})-1;
			var one16 = listd.getRange({fromIndex:0, toIndex:c16});
			nf.alert({text:one16, title:"删除第2/4/6条数据并获取全部数据"}, function(data, e){});
			break;
		case 17:
			var m17 = listdata.getOne(17);
			var m17v1 = m17.VALUE1;
			var m17v2 = m17.VALUE2;
			listd.updateOne({index:m17v1, data:m17v2});
			var  c17 = listd.getCount({})-1;
			var one17 = listd.getRange({fromIndex:0, toIndex:c17});
			nf.alert({text:one17, title:"更新第一条数据"}, function(data, e){});
			break;
		case 18:
			var m18 = listdata.getOne(18);
			var m18v1 = m18.VALUE1;
			var m18v2 = m18.VALUE2;
			listd.updateOne({index:m18v1, data:m18v2});
			var  c18 = listd.getCount({})-1;
			var one18 = listd.getRange({fromIndex:0, toIndex:c18});
			nf.alert({text:one17, title:"数组越界更新0条数据"}, function(data, e){});
			break;
	}
});
