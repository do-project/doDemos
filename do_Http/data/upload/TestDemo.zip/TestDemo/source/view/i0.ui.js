var root = ui("$");

root.setMapping({
	"IMG.source":"$img",
	"LABEL.text":"$txt"
});