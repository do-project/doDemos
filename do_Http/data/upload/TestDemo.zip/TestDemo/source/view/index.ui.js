/**********************************************
 * Author : @zhuyu
 * Timestamp : @Timestamp
 **********************************************/
var app = sm("do_App");
var page = sm("do_Page");
var nf = sm("do_Notification");

var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

/****************************/
var listview , listdata;
listview = ui("list1");
listdata = mm("do_ListData");
listview.bindItems(listdata);

var data0 = [
	{"$img":"data://0.png","$txt":"核心组件 \\ Core","$tag":"CORE" },
	{"$img":"data://1.png","$txt":"单实例组件 \\ Singleton Module","$tag":"SM" },
	{"$img":"data://2.png","$txt":"多实例组件 \\ Multiple Module","$tag":"MM" },
	{"$img":"data://3.png","$txt":"可视化组件 \\ User Interface","$tag":"UI" },
	{"$img":"data://4.png","$txt":"其他测试 \\ Others Test","$tag":"OTHERS" }
];

listdata.addData(data0);
listview.refreshItems();

listview.on("touch",function(index){
	var a = listdata.getOne(index);
	//var b = a.$tag;
	app.openPage("source://view/index1.ui",a);
});
