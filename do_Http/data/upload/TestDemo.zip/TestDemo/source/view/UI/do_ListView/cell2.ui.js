var root = ui("$");

root.setMapping({
	"img0.source":"$1",
	"img0.width":"$width",
	"img0.height":"$height"
});

var img0 = ui("img0");
img0.on("dataRefreshed",function(data, e){
	deviceone.print("aaaa");
	root.redraw();
});