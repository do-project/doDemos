ui("$").setMapping({
	"do_ImageView_1.source":"$rightImage"
})