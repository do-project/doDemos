var root = ui("$");
var nf = sm("do_Notification");

root.setMapping({
	"do_Label_3.text":"$3"
});

ui("target").on("touch",function(){
	
	nf.alert("cancel");
})