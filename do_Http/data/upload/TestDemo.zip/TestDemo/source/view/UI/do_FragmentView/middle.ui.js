ui("$").setMapping({
	"do_Label_1.text":"$2"
})


var global = sm("do_Global");
var left = ui("do_Button_2");
var right = ui("do_Button_3");


left.on("touch",function(){
	global.fire("openleft");
})

right.on("touch",function(){
	global.fire("openright");
})