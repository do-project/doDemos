var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data1 = [
    {
        "path": "data://2.jpg",
        "duration": 500
    },
    {
        "path": "data://3.jpg",
        "duration": 500
    },
    {
        "path": "data://4.jpg",
        "duration": 500
    }
];
var data2 = [
	{
        "path": "source://6.jpg",
        "duration": 1000
    },
    {
        "path": "source://9.jpg",
        "duration": 1000
    },
    {
        "path": "source://10.jpg",
        "duration": 1000
    }
 ];

var data0 =[
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},{template:0,"$1":"on2","$2":"method"},
	{template:0,"$1":"fire2","$2":"method"},
	{template:0,"$1":"startImages(data)","$2":"method"},{template:0,"$1":"startImages(source)","$2":"method"},
	{template:0,"$1":"startGif(data)","$2":"method"},{template:0,"$1":"startGif(source)","$2":"method"},
	{template:0,"$1":"stop","$2":"method"},
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,100,10,10"},
	{template:0,"$1":"gifSource","$2":"data://1.gif"},{template:0,"$1":"gifSource","$2":"source://2.gif"},
	{template:0,"$1":"imagesSource","$2":data1},{template:0,"$1":"imagesSource","$2":data2}
];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
	if (index == 0)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 1)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 2)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 3)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 4)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 5)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 6)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else if (index == 7)
	{	
		target.startImages({data:data1, repeat:1});
		nf.alert({text:"开始动画", title:"重复一次"}, function(data, e){});
	}
	else if (index == 8)
	{	
		target.startImages({data:data2, repeat:-1});
		nf.alert({text:"开始动画", title:"无限循环"}, function(data, e){});
	}
	else if (index == 9)
	{
		target.startGif({data:"data://1.gif", repeat:1});
		nf.alert({text:"开始动画", title:"重复一次"}, function(data, e){});
	}
	else if (index == 10)
	{
		target.startGif({data:"source://2.gif", repeat:-1});
		nf.alert({text:"开始动画", title:"无限循环"}, function(data, e){});
	}
	else if (index == 11)
	{
		target.stop({});
		nf.toast({text:"stop FrameAnimation"}, function(data, e){});
	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});


target.on("touch",function(data, e){
	nf.toast("touch event is fired");
});

target.on("touchDown",function(data, e){
	nf.toast("touchDown event is fired");
});

target.on("touchUp",function(data, e){
	nf.toast("touchUp event is fired");
});