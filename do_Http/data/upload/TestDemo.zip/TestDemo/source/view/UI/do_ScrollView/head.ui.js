﻿
ui("do_Button_1").on("touch",function(){
	
	deviceone.print("touch");
})