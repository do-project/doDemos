//related to test.ui
var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");


ui("do_Button_1").on("touch",function(){
	app.closePage();
})

var do_TextField_1 = ui("do_TextField_1");
page.on("loaded",function(){
	do_TextField_1.setFocus(true);
})