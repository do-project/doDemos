var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");
var do_linearlayout_1 = ui("do_linearlayout_1");
/***********************/

target.on("dataRefreshed",function(data, e){
	nf.alert({text:"dataRefreshed event is fired", title:""}, function(data, e){});
});

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},
	{template:0,"$1":"on2","$2":"method"},{template:0,"$1":"fire2","$2":"method"},
	{template:0,"$1":"off1","$2":"method"},{template:0,"$1":"off2","$2":"method"},
	{template:0,"$1":"dataRefresh","$2":"method"},
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,100,10,10"}
	
];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
	do_linearlayout_1.redraw({});
	if (index == 0)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 1)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 2)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 3)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 4)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 5)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 6)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else if (index == 7)
	{
		target.off({name:"name1"});
	}
	else if (index == 8)
	{
		target.off({name:"name2"});
	}
	else if (index == 9)
	{
		//nf.alert({text:"dataRefreshed", title:""}, function(data, e){});
		var hh = mm("do_HashData");
		var dd = {"item1_text":"ttttttt","item1_color":"800080FF"};
		hh.addData(dd);
		
		target.bindData({data:hh, mapping:{"text":"item1_text","bgColor":"item1_color"}});
		target.refreshData({});

	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});


target.on("touch",function(data, e){
	nf.alert("touch event");
	//target.bgColor = "FF0000FF";
});

target.on("touchDown",function(data, e){
	//nf.toast("touchDown event is fired");
	target.bgColor = "FF0000FF";
});

target.on("touchUp",function(data, e){
	//nf.toast("touchUp event is fired");
	target.bgColor = "FFFFFFFF";
});

