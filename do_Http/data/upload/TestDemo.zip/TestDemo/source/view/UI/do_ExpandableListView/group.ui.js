var $ = ui("$");

$.setMapping({
	"do_Label_2.text":"$t",
	"do_ImageView_2.source":"$s"
});