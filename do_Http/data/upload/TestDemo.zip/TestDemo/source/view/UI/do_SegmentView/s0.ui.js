var $ = ui("$");

$.setMapping({
	"do_label_1.text":"$1",
	"do_imageview_1.source":"$2"
});