var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,10,10,10"},
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},{template:0,"$1":"on2","$2":"method"},
	{template:0,"$1":"fire2","$2":"method"},{template:0,"$1":"checked","$2":"true"},{template:0,"$1":"checked","$2":"false"},
];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
	if (index == 8)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 9)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 10)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 11)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 12)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 13)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 14)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});


target.on("changed",function(data, e){
	nf.alert({text:data, title:"开关状态改变"}, function(data, e){});
});