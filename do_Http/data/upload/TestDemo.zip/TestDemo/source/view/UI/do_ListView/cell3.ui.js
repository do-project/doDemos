//related to cell3.ui
var root = ui("$");

root.setMapping({
	"do_RichLabel_1.text":"$1"
});
