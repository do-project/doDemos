﻿var nf = sm("do_Notification");

ui("do_Button_1").on("touch",function(){
	
	nf.alert("header");
})