var root = ui("$");

root.setMapping({
	"do_button_1.text":"$1",
	"do_imageview_1.source":"$2"
});
