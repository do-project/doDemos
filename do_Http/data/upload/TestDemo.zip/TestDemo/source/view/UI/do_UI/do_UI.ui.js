var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");
var linearlayout1 = ui("do_linearlayout_1");
var alayout1 = ui("do_ALayout_2");
/***********************/

target.on("dataRefreshed",function(data, e){
	nf.alert({text:"dataRefreshed event is fired", title:""}, function(data, e){});
});

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{"$1":"show_slide_l2r","$2":"method"},
	{"$1":"show_slide_r2l","$2":"method"},
	{"$1":"show_slide_b2t","$2":"method"},
	{"$1":"show_slide_t2b","$2":"method"},
	{"$1":"show_expand_l2r","$2":"method"},
	{"$1":"show_expand_t2b","$2":"method"},
	{"$1":"show_fadein","$2":"method"},
	{"$1":"hide_slide_l2r","$2":"method"},
	{"$1":"hide_slide_r2l","$2":"method"},
	{"$1":"hide_slide_b2t","$2":"method"},
	{"$1":"hide_slide_t2b","$2":"method"},
	{"$1":"hide_collapse_r2l","$2":"method"},
	{"$1":"hide_collapse_b2t","$2":"method"},
	{"$1":"hide_fadeout","$2":"method"},
	{"$1":"get_Visible","$2":"method"}
];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	if (index == 0)
	{
		linearlayout1.show("slide_l2r", 3000);
		alayout1.show("slide_l2r", 5000);
	}
	else if (index == 1)
	{
		linearlayout1.show("slide_r2l", 3000);
		alayout1.show("slide_r2l", 5000);
	}
	else if (index == 2)
	{
		linearlayout1.show("slide_b2t", 3000);
		alayout1.show("slide_b2t", 5000);
	}
	else if (index == 3)
	{
		linearlayout1.show("slide_t2b", 3000);
		alayout1.show("slide_t2b", 5000);
	}
	else if (index == 4)
	{
		linearlayout1.show("expand_l2r", 3000);
		alayout1.show("expand_l2r", 5000);
	}
	else if (index == 5)
	{
		linearlayout1.show("expand_t2b", 3000);
		alayout1.show("expand_t2b", 5000);
	}
	else if (index == 6)
	{
		linearlayout1.show("fadein", 3000);
		alayout1.show("fadein", 5000);
	}
	else if (index == 7)
	{
		linearlayout1.hide("slide_l2r", 5000)
		alayout1.hide("slide_l2r", 4000)
	}
	else if (index == 8)
	{
		linearlayout1.hide("slide_r2l", 5000)
		alayout1.hide("slide_r2l", 4000)
	}
	else if (index == 9)
	{
		linearlayout1.hide("slide_b2t", 5000)
		alayout1.hide("slide_b2t", 4000)
	}
	else if (index == 10)
	{
		linearlayout1.hide("slide_t2b", 5000)
		alayout1.hide("slide_t2b", 4000)
	}
	else if (index == 11)
	{
		linearlayout1.hide("collapse_r2l", 5000)
		alayout1.hide("collapse_r2l", 4000)
	}
	else if (index == 12)
	{
		linearlayout1.hide("collapse_b2t", 5000)
		alayout1.hide("collapse_b2t", 4000)
	}
	else if (index == 13)
	{
		linearlayout1.hide("fadeout", 5000)
		alayout1.hide("fadeout", 4000)
	}
	else if (index == 14)
	{
		var visible1 = linearlayout1.get("visible");
		var visible2 = alayout1.get("visible");
		deviceone.print(visible1,"linearlayout's visible");
		deviceone.print(visible2,"alayout1's visible");
	}
});



