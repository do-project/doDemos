var root = ui("$");

root.setMapping({
	"do_Label_1.text":"$1"
});
