var $ = ui("$");

$.setMapping({
	"do_label_1.text":"$1"
});