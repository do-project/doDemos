//related to s1.ui
var $ = ui("$");

$.setMapping({
	"do_ImageView_1.source":"$0"
});
