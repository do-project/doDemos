var root = ui("$");

root.setMapping({
	"do_button_1.text":"text",
	"do_imageview_1.source":"img"
});