//related to left_cell.ui
ui("$").setMapping({
	"do_Label_1.text":"$1",
	"do_Label_2.text":"$2"
})