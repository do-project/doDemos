ui("$").setMapping({
	"do_ImageView_1.source":"$leftImage"
})

var list = ui("do_ListView_2");
var listdata = mm("do_ListData");

var data0 = [
    {"$1":"我的消息","$2":"我的消息123"},
    {"$1":"设置","$2":"设置123"},
    {"$1":"我的邮箱","$2":"我的邮箱123"},
    {"$1":"我的任务","$2":"我的任务123"}
]

listdata.addData(data0);
list.bindItems(listdata);


