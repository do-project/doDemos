var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,10,10,10"},
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},{template:0,"$1":"on2","$2":"method"},
	{template:0,"$1":"fire2","$2":"method"},
	{template:0,"$1":"rebound","$2":"method"}
];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
	if (index == 8)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 9)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 10)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 11)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 12)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 13)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 14)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else if (index == 15)
	{
		target.rebound({});
	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});

var data2 = mm("do_HashData");

data2.addData({"A":[{"template":2},{"template":1,"text1":"A"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"呵":[{"template":2},{"template":1,"text1":"呵"},{"template":0,"text":"哈哈哈哈哈哈","img":"data://0.png"}]});
data2.addData({"C":[{"template":2},{"template":1,"text1":"C"},{"template":0,"text":"ccccc","img":"data://0.png"}]});
data2.addData({"B":[{"template":2},{"template":1,"text1":"B"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"D":[{"template":1,"text1":"D"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"E":[{"template":1,"text1":"E"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"F":[{"template":1,"text1":"F"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"G":[{"template":1,"text1":"G"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"H":[{"template":1,"text1":"H"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"I":[{"template":1,"text1":"I"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"J":[{"template":1,"text1":"J"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"K":[{"template":1,"text1":"K"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"L":[{"template":1,"text1":"L"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"M":[{"template":1,"text1":"M"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"N":[{"template":1,"text1":"N"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"O":[{"template":1,"text1":"O"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"P":[{"template":1,"text1":"P"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"Q":[{"template":1,"text1":"Q"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"R":[{"template":1,"text1":"R"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"S":[{"template":1,"text1":"S"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"T":[{"template":1,"text1":"T"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"U":[{"template":1,"text1":"U"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"V":[{"template":1,"text1":"V"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});
data2.addData({"W":[{"template":1,"text1":"W"},{"template":0,"text":"aaaaa","img":"data://0.png"}]});

//var datatt = {
//	"L" : [{
//			"template" : 0,
//			"index" : "L"
//		}, {
//			"template" : 1,
//			"index" : "L",
//			"empItcode" : "liuhbg"
//		}
//	],
//	"G" : [{
//			"template" : 0,
//			"index" : "G"
//		}, {
//			"template" : 1,
//			"index" : "G",
//			"empItcode" : "guowei"
//		}
//	]
//}

//data2.addData(datatt);

target.bindItems(data2,["呵","C","A","B","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W"]);
//target.bindItems(data2,["G","L"]);
target.refreshItems({});

target.on("longTouch",function(data, e){
	var ii = data2.getAll({});
	var index1 = data.index;
	var groupID = data.groupID;
	//ii = ii[groupID][index1].text;
	ii = ii[groupID][1].text;
	nf.alert({text:ii, title:"点击的cell的数据的值"}, function(data, e){});
});

target.on("touch",function(data, e){
	
	var index2 = data.index;
	nf.alert({text:index2, title:"当前cell的position值"}, function(data, e){});
	var dd2 = data2.getOne({key:index2});
	nf.alert({text:dd2, title:"当前cell的值"}, function(data, e){});
});
