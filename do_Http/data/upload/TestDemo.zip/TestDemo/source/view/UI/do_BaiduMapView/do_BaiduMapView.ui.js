var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");
//var do_linearlayout_1 = ui("do_linearlayout_1");

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},
	{template:0,"$1":"on2","$2":"method"},{template:0,"$1":"fire2","$2":"method"},
	{template:0,"$1":"off1","$2":"method"},{template:0,"$1":"off2","$2":"method"},
	{template:0,"$1":"setCenter默认值","$2":"method"},{template:0,"$1":"setCenter","$2":"method"},
	{template:0,"$1":"addMarkers","$2":"method"},
	{template:0,"$1":"removeMarker","$2":"method"},
	{template:0,"$1":"removeAll","$2":"method"},
	{template:0,"$1":"getDistance1","$2":"method"},
	{template:0,"$1":"getDistance2","$2":"method"},
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,100,10,10"},
	{template:0,"$1":"mapType","$2":"standard"},
	{template:0,"$1":"mapType","$2":"satellite"}
	
];

listdata.addData(data0);
grid.refreshItems({});

var mark1 = [{"id":"id1","latitude":"40.0564640000","longitude":"116.3080720000","url":"data://0.png","info":"百度大厦"},
			 {"id":"id2","latitude":"40.0591700000","longitude":"116.3074610000","url":"data://1.png","info":"辉煌国际"}
			];

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
	//do_linearlayout_1.redraw({});
	if (index == 0)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 1)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 2)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 3)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 4)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 5)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 6)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else if (index == 7)
	{
		target.off({name:"name1"});
	}
	else if (index == 8)
	{
		target.off({name:"name2"});
	}
	else if (index == 9)
	{
		target.setCenter({latitude:"39.915174", longitude:"116.403901"});
	}
	else if (index == 10)
	{
		target.setCenter({latitude:"40.0574570000", longitude:"116.3100920000"});
	}
	else if (index == 11)
	{
		target.addMarkers({data:mark1});
	}
	else if (index == 12)
	{
		target.removeMarker({ids:["id1"]});
	}
	else if (index == 13)
	{
		target.removeAll({});
	}
	else if (index == 14)
	{
		var distance1 = target.getDistance(39.9151120000,116.4039630000, 40.0589220000,116.3126150000);
		nf.alert(distance1,"从天安门到西二旗的距离");
		
	}
	else if (index == 15)
	{
		var distance2 = target.getDistance(40.0162900000,116.3146070000, 29.1263290000,113.0215300000);
		nf.alert(distance2,"从圆明园到洞庭湖的距离");
	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});


target.on("touchMarker",function(data, e){
	nf.alert({text:"touchMarker event is fired", title:""}, function(data, e){});
});