var $ = ui("$");
var nf = sm("do_Notification");

$.setMapping({
	"do_Label_1.text":"$1",
	"do_ImageView_2.source":"$2",
	"do_CheckBox_1.text":"$3"
});

var check = ui("do_CheckBox_1");
check.on("checkChanged",function(index){
	nf.toast(index);
})

var img = ui("do_ImageView_2");
img.on("touch",function(){
	nf.alert("touched");
})