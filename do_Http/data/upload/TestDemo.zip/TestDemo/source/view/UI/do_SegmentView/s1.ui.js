var $ = ui("$");

$.setMapping({
	"do_imageview_1.source":"$2"
});