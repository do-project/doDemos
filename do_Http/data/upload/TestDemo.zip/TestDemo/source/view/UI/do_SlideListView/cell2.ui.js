var root = ui("$");
var nf = sm("do_Notification");

root.setMapping({
	"do_Label_2.text":"$4"
});

ui("target").on("touch",function(){
	
	nf.alert("confirm");
})