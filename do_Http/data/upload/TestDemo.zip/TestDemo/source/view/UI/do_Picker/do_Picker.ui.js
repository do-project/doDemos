var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");

var data2 = ["a","b","c","d","e","f","g","h","i"]

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var grid = ui("do_gridview_1");
var listdata = mm("do_ListData");
grid.bindItems(listdata);

var data0 =[
	{template:0,"$1":"getType","$2":"method"},{template:0,"$1":"getAddress","$2":"method"},{template:0,"$1":"getRect","$2":"method"},
	{template:0,"$1":"on1","$2":"method"},{template:0,"$1":"fire1","$2":"method"},
	{template:0,"$1":"on2","$2":"method"},{template:0,"$1":"fire2","$2":"method"},
	{template:0,"$1":"off1","$2":"method"},{template:0,"$1":"off2","$2":"method"},
	{template:0,"$1":"refreshItems","$2":"method"},
	{template:0,"$1":"x","$2":"0"},{template:0,"$1":"y","$2":"110"},{template:0,"$1":"width","$2":"50"},
	{template:0,"$1":"height","$2":"50"},{template:0,"$1":"visible","$2":"true"},
	{template:0,"$1":"visible","$2":"false"},{template:0,"$1":"bgColor","$2":"0080FFFF"},{template:0,"$1":"margin","$2":"10,100,10,10"},
	{template:0,"$1":"index","$2":"2"},{template:0,"$1":"index","$2":"5"},{template:0,"$1":"index","$2":"-1"},{template:0,"$1":"index","$2":"100"}
        ];

listdata.addData(data0);
grid.refreshItems({});

grid.on("touch",function(index){
	var D = listdata.getOne(index);
	var a = D.$1;
	var b = D.$2;
	var h = { };
	h[a] = b;
	target.set(h);
	target.redraw({});
//	do_linearlayout_1.redraw({});
	if (index == 0)
	{
		var v1 = target.getType({});
		nf.alert(v1);
	}
	else if (index == 1)
	{
		var v2 = target.getAddress({});
		nf.alert(v2);
	}
	else if (index == 2)
	{
		var v3 = target.getRect({});
		nf.alert(v3);
	}
	else if (index == 3)
	{
		target.on({name:"name1", data:"123456你好", delay:-1}, function(data, e){
			nf.toast("立即执行fire1消息可用");
			nf.toast(data);
		});
	}
	else if (index == 4)
	{
		target.fire({name:"name1", data:"654321#￥%"});
	}
	else if (index == 5)
	{
		target.on({name:"name2", data:"abcdef@#￥", delay:5}, function(data, e){
			nf.toast("第一次执行后5秒内无法继续执行fire2");
			nf.toast(data);
		});
	}
	else if (index == 6)
	{
		target.fire({name:"name2", data:"fedcba你好"});
	}
	else if (index == 7)
	{
		target.off({name:"name1"});
	}
	else if (index == 8)
	{
		target.off({name:"name2"});
	}
	else if (index == 9)
	{	
		var listdata11 = mm("do_ListData");
		var data11 = ["a","b","c","d","e","f","g","h"]
		listdata11.addData(data11);

		target.bindItems(listdata11);
		target.refreshItems();
	}
	else
	{
		var v = target.get(a);
		nf.alert({text:v, title:a}, function(data, e){});
	}
});

var listdata = mm("do_ListData");
var data1 = ["2000","2001","2002","2003","2004","2005","2006","2007","2008"]

listdata.addData(data1);

target.bindItems(listdata);


target.on("selectChanged",function(data, e){
//	nf.alert({text:data, title:"selectChanged event"}, function(data, e){});
	deviceone.print(data,"selectChanged")
});