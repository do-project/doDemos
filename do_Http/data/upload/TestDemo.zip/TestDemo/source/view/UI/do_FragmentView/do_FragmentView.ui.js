var app = sm("do_App");
var page = sm("do_Page");
var storage = sm("do_Storage");
var nf = sm("do_Notification");
var target = ui("target");
var global = sm("do_Global");
//global.setMemory("frag", target);

/***********************/
var img1 = ui("img1");
img1.on("touch",function(data, e){
	app.closePage({data:"", animationType:""}, function(data, e){});
});

var name = page.getData({});
var lb1 = ui("lb1");
lb1.text = name;
/***********************/
var data2 = mm("do_ListData");

var datag = [
	{ leftTemplate:0,template:1,rightTemplate:2,"$leftImage":"data://00.jpg","$2":"777","$rightImage":"data://1434074252385.jpg"}
//	{ template:0,"$1":"middle page"},
//    { rightTemplate:2,"$1":"abcde12345"}
];

data2.addData(datag);
target.bindItems(data2);


global.on("openleft",function(data, e) {
	target.showLeft();
	deviceone.print("showLeft11")
})
global.on("openright",function(data, e) {
	target.showRight();
	deviceone.print("showRight11")
})

