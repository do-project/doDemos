var $ = ui("$");

$.setMapping({
	"do_label_1.text":"text1"
});