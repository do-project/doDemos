var rootview;
rootview = ui("$");

rootview.setMapping({
    "lb_text.text":"text"
});