var rootview, page;
rootview = ui("$");

rootview.setMapping({
    "img.source":"img"
});