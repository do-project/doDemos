var rootview;
rootview = ui("$");

rootview.setMapping({
    "NAME.text" : "NAME",
    "IMG.source" : "IMG",
    "MSG.text" : "MSG",
    "VERSION.text" : "VERSION"
});



