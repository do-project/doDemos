//related to cell.ui
var root = ui("$");

root.setMapping({
	"name_label.text" : "name",
	"index_label.text" : "index"
});